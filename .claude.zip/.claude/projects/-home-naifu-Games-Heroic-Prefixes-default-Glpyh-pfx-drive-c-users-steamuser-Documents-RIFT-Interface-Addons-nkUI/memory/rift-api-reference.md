# RIFT API Complete Reference
## Compiled from official docs (seebs.net/rift/live) + nkUI codebase analysis
## Last updated: 2026-03-01

---

## CRITICAL RULES (Read First)

1. **Lua 5.1 only** — no `goto`, no `//`, no `&|~` bitwise ops, use `unpack()` not `table.unpack()`
2. **SetPoint anchors**: TOPLEFT TOPCENTER TOPRIGHT CENTERLEFT CENTER CENTERRIGHT BOTTOMLEFT BOTTOMCENTER BOTTOMRIGHT CENTERBOTTOM — `TOP/BOTTOM/LEFT/RIGHT` are INVALID
3. **Key events**: `function(self, _, key)` — key is 3rd param; special keys: "Shift" "Control" "Alt"; regular: lowercase "q" "1" "space"
4. **LibEKL widget events** → `Command.Event.Attach(LibEKL.Events[name].EventName, ...)` NEVER `frame:EventAttach`
5. **Event.Unit.Availability.Full** → detach after init, attach only once
6. **Inspect.* calls may fail** → wrap in `pcall()` when data may be unavailable
7. **Never pre-call CheckEvents** for widget names — widgets do it internally

---

## Startup Event Order

```
1. Event.Addon.SavedVariables.Load.End  → (_, addon) — SavedVars available here
2. Event.Unit.Availability.Full         → (_, info)  — unit data available, DETACH after init
```

```lua
Command.Event.Attach(Event.Addon.SavedVariables.Load.End, function(_, addon)
    if addon ~= addonInfo.identifier then return end
    -- register fonts, slash commands
    Command.Event.Attach(Event.Unit.Availability.Full, function()
        LibEKL.Unit.Init()
        LibEKL.Inventory.Init(false, false)
        -- init modules, create UI, attach ongoing events
        Command.Event.Detach(Event.Unit.Availability.Full, nil, "nkUI.Unit.Availability.Full")
    end, "nkUI.Unit.Availability.Full")
end, "nkUI.SavedVariables.Load.End")
```

---

## Inspect.* Namespace

### Inspect.Time
```
Inspect.Time.Real()     → float  — real elapsed seconds (high precision, rate limiting)
Inspect.Time.Frame()    → int    — frame counter
```

### Inspect.System
```
Inspect.System.Secure()     → bool   — true = in combat/secure mode
Inspect.System.Watchdog()   → float  — CPU budget 0.0-1.0 (>= 0.1 = safe for expensive ops)
Inspect.System.Language()   → string — "English" "German" "French" "Russian"
```

### Inspect.Addon
```
Inspect.Addon.Current()  → table {identifier, id, name, toc={Version,...}, ...}
```

### Inspect.Unit
```
Inspect.Unit.Detail(unitID)         → table {id, name, level, health, healthMax, energy, energyMax,
                                              power, mana, charge, combo, planar, zone, role, mark,
                                              class, calling, race, faction, afk, offline, ready,
                                              locationName, coord={x,y,z}}
Inspect.Unit.Lookup(criteria)       → table of unit IDs
Inspect.Unit.Castbar(unitID)        → table {abilityName, duration, uninterruptible} or nil
Inspect.Unit.List()                 → table of unitIDs
```
Unit type strings: "player" "player.pet" "player.target" "player.target.target"
                   "focus" "focus.target" "group01"-"group20" "group01.pet" etc.

### Inspect.Buff
```
Inspect.Buff.Detail(unitID, buffID)  → table {name, icon, duration, stacks, caster, ...}
Inspect.Buff.List(unitID)            → table {buffID → true, ...}
```

### Inspect.Ability
```
Inspect.Ability.Detail(abilityID)       → table (old API)
Inspect.Ability.New.Detail(abilityID)   → table {name, icon, type, ...}
```

### Inspect.Item
```
Inspect.Item.Detail(itemID)  → table {name, icon, rarity, type, bagSlot, stackCount,
                                      category, typeId, level, bind, bound, ...}
```
Rarity values: "sellable" "uncommon" "rare" "epic" "relic" "transcendent" "quest"

### Inspect.Quest
```
Inspect.Quest.Detail(questKey)  → table {id, name, level, complete, category,
                                         objective={...}, location, reward={...}, ...}
Inspect.Quest.List()            → table {questKey1, questKey2, ...}
```

### Inspect.Auction
```
Inspect.Auction.Detail(auction)   → detail table {bid, buyout, seller, remaining, item, ...}
Inspect.Auction.Detail(auctions)  → {auctionID → detail, ...}
```

### Inspect.Currency
```
Inspect.Currency.Detail(id)           → table {name, category, icon, stack, stackMax, ...}
Inspect.Currency.List()               → table {id → amount, ...}
Inspect.Currency.Category.List()      → table {id → true, ...}
Inspect.Currency.Category.Detail(id)  → table {id, name}
```

### Inspect.Experience
```
Inspect.Experience()  → table {accumulated, needed, rested}
```

### Inspect.Stat
```
Inspect.Stat()          → table {statName → value, ...}
Inspect.Stat(statName)  → number
```
Stat names: "strength" "dexterity" "intelligence" "wisdom" "endurance"
            resistance types, "armor" "powerAttack" "critAttack"
            Add "Unbuffed" suffix for unbuffed values

### Inspect.Map
```
Inspect.Map.Detail()         → table {id, name, ...}
Inspect.Map.List()           → table of map IDs
Inspect.Map.Waypoint.Get(unitID) → x, y, z or nil
```

### Inspect.Zone
```
Inspect.Zone.Detail(zoneID)   → table {id, name, type}
Inspect.Zone.Detail(zoneIDs)  → {zoneID → detail, ...}
```

### Inspect.Mouse / Inspect.Cursor / Inspect.Tooltip
```
Inspect.Mouse()          → table {x, y}
Inspect.Cursor()         → itemType, itemID  or nil
Inspect.Tooltip()        → type, shownElement  or  type, unit, buffID
```

### Inspect.Interaction
```
Inspect.Interaction()  → current interaction target or nil
```

---

## Command.* Namespace

### Command.Event
```
Command.Event.Attach(eventHandle, callback, label, [priority])
Command.Event.Detach(eventHandle, [callback], label, [priority], [owner])
```
- label must be UNIQUE globally — use "AddonName.Module.EventName" pattern
- Detach by label: pass `nil` as callback, matching label

### Command.Console
```
Command.Console.Display(channel, show, message, [isHTML])
-- channel: "general"
-- message supports: <font color="#RRGGBB">text</font>
```

### Command.Slash
```
table.insert(Command.Slash.Register("cmdname"), {handler, "addonID", "handlerName"})
-- handler receives: function(commandline) where commandline = text after /cmdname
```

### Command.Script
```
Command.Script.Reload()  — reload UI
```

### Command.Map
```
Command.Map.Waypoint.Set(x, y)
Command.Map.Waypoint.Clear()
Command.Map.Monitor(flag)
```

### Command.Item
```
Command.Item.Move(fromSlot, toSlot)  — wrap in pcall
```

### Command.Auction
```
Command.Auction.Scan(parameters)
Command.Auction.Bid(auction, bid, [quantity], [callback])
Command.Auction.Post(item, time, bid, buyout, [partial], [callback])
Command.Auction.Cancel(auction, [callback])
Command.Auction.Order(itemtype, quantity, time, buyout, [callback])
Command.Auction.Fulfill(auction, item, quantity, [callback])
Command.Auction.Analyze(itemtype, begin, end, [callback])
-- time durations: 12, 24, or 48 hours
```

### Command.Mail
```
Command.Mail.Send(mail, [callback])
Command.Mail.Delete(mail, [callback])
Command.Mail.Open(mail, [callback])
Command.Mail.Pay(mail, [callback])        — pay COD
Command.Mail.Return(mail, [callback])
Command.Mail.Spam(mail, [callback])
Command.Mail.Take(mail, item, [callback])
Command.Mail.Take(mail, items, [callback])
```

### Command.Message
```
Command.Message.Send(target, identifier, data, callback)
Command.Message.Accept(channel, identifier)  — channel nil = whispers
```

### Command.Tooltip
```
Command.Tooltip(id)       — show tooltip for ability/item/itemtype/unit
Command.Tooltip(nil)      — hide tooltip
```

---

## Event.* Reference

### Global Startup
```
Event.Addon.SavedVariables.Load.End   → (_, addon)
```

### System
```
Event.System.Update.Begin   → ()  runs ~60/sec — NO heavy logic, check watchdog
Event.System.Update.End     → ()
Event.System.Secure.Enter   → (_, info)
Event.System.Secure.Leave   → (_, info)
```

### Unit
```
Event.Unit.Availability.Full   → (_, info={unitID,...})  DETACH AFTER INIT
Event.Unit.Availability.None   → (_, info={unitID,...})
Event.Unit.Detail.Health       → (_, {unitID→value,...})
Event.Unit.Detail.HealthMax    → (_, {unitID→value,...})
Event.Unit.Detail.Energy       → (_, {unitID→value,...})
Event.Unit.Detail.EnergyMax    → (_, {unitID→value,...})
Event.Unit.Detail.Power        → (_, {unitID→value,...})
Event.Unit.Detail.Mana         → (_, {unitID→value,...})
Event.Unit.Detail.Charge       → (_, {unitID→value,...})
Event.Unit.Detail.Combo        → (_, {unitID→value,...})
Event.Unit.Detail.Planar       → (_, {unitID→value,...})
Event.Unit.Detail.Role         → (_, {unitID→value,...})
Event.Unit.Detail.Zone         → (_, {unitID→value,...})
Event.Unit.Detail.Afk          → (_, {unitID→value,...})
Event.Unit.Detail.Offline      → (_, {unitID→value,...})
Event.Unit.Detail.Mark         → (_, {unitID→value,...})
Event.Unit.Detail.Ready        → (_, {unitID→value,...})
Event.Unit.Detail.LocationName → (_, {unitID→value,...})
Event.Unit.Detail.Coord        → (_, x, y, z)
Event.Unit.Castbar             → (_, {unitID→bool,...})
```

### Buff
```
Event.Buff.Add     → (_, unit, {buffID→details,...})
Event.Buff.Change  → (_, unit, {buffID→details,...})
Event.Buff.Remove  → (_, unit, {buffID→details,...})
```

### Ability
```
Event.Ability.New.Usable.True     → (_, {abilityID,...})
Event.Ability.New.Usable.False    → (_, {abilityID,...})
Event.Ability.New.Range.True      → (_, {abilityID,...})
Event.Ability.New.Range.False     → (_, {abilityID,...})
Event.Ability.New.Cooldown.Begin  → (_, {abilityID→remainingSec,...})
Event.Ability.New.Cooldown.End    → (_, {abilityID,...})
```

### Combat
```
Event.Combat.Damage  → (_, damageInfo)
Event.Combat.Death   → (_, info)
```

### Quest
```
Event.Quest.Accept    → (_, questKey)
Event.Quest.Abandon   → (_, questKey)
Event.Quest.Change    → (_, questKey)
Event.Quest.Complete  → (_, questKey)
```

### Item
```
Event.Item.Slot    → (_, {slotID→itemInfo,...})
Event.Item.Update  → (_, {slotID→itemInfo,...})
```

### Currency & Experience
```
Event.Currency                  → (_, currencyData)
Event.Experience.Accumulated    → (_, value)
Event.Experience.Rested         → (_, value)
```

### Auction
```
Event.Auction.Statistics  → fired after Command.Auction.Analyze
```

### Chat
```
Event.Chat.Receive  → (_, chatData)
```

### Map
```
Event.Map.Add               → map element added
Event.Map.Change            → map element changed
Event.Map.Remove            → map element removed
Event.Map.Detail.Coord      → (_, x, y, z)
Event.Map.Waypoint.Update   → waypoint updated
```

### Tooltip
```
Event.Tooltip  → (_, type, shownElement)
```

### UI Input (frame:EventAttach ONLY)
```
Event.UI.Input.Mouse.Left.Down        → (self, _, x, y)
Event.UI.Input.Mouse.Left.Up          → (self, _, x, y)
Event.UI.Input.Mouse.Left.Click       → (self, _, x, y)
Event.UI.Input.Mouse.Left.Upoutside   → (self)
Event.UI.Input.Mouse.Right.Down       → (self, _, x, y)
Event.UI.Input.Mouse.Right.Click      → (self, _, x, y)
Event.UI.Input.Mouse.Right.Down.Bubble → (self, _, x, y)
Event.UI.Input.Mouse.Middle.Click     → (self, _, x, y)
Event.UI.Input.Mouse.Cursor.In        → (self)
Event.UI.Input.Mouse.Cursor.Out       → (self)
Event.UI.Input.Mouse.Cursor.Move      → (self, _, x, y)
Event.UI.Input.Mouse.Wheel.Forward    → (self)
Event.UI.Input.Mouse.Wheel.Back       → (self)
Event.UI.Input.Key.Down   → (self, _, key)  key="Shift"/"Control"/"Alt" or lowercase "q"/"1"/"space"
Event.UI.Input.Key.Up     → (self, _, key)
Event.UI.Input.Key.Type   → (self, text)    text = typed character(s)
Event.UI.Input.Key.Repeat → (self, _, key)
Event.UI.Input.Key.Focus.Gain  → (self)
Event.UI.Input.Key.Focus.Loss  → (self)
Event.UI.Layout.Size           → (self)
Event.UI.Native.Loaded         → fired when native UI element loads
```

---

## UI Frame System

### Context Creation
```lua
local context = UI.CreateContext("nkUI.ModuleName")
context:SetStrata('hud')         -- 'hud' 'notify' 'dialog' 'tooltip' 'fullscreen' 'topmost'
context:SetLayer(2)              -- z-order, higher = on top
context:SetSecureMode('restricted')  -- for combat-safe frames
```

### UI.CreateFrame Types
```
"Frame"         — container (use nkFrame via LibEKL instead)
"Text"          — text (use nkText via LibEKL instead)
"Texture"       — image (use nkTexture via LibEKL instead)
"Canvas"        — vector drawing (use nkCanvas via LibEKL instead)
"Mask"          — clipping mask
"Layout"        — layout manager
"RiftButton"    — native game button
"RiftCheckbox"  — native game checkbox
"RiftScrollbar" — native game scrollbar
"RiftSlider"    — native game slider
"RiftTextfield" — native game text input
"RiftWindow"    — native game window (has GetContent(), GetTitle(), SetTitle())
```

### Universal Frame Methods
```lua
-- Positioning
frame:SetPoint(from, anchor, to, xOff, yOff)  -- anchors: see CRITICAL RULES
frame:ClearPoint(anchor)
frame:ClearAll()
frame:ReadPoint(anchor)         → table
frame:SetAllPoints(other)

-- Size
frame:SetWidth(n)
frame:SetHeight(n)
frame:GetWidth()  → number
frame:GetHeight() → number
frame:ClearWidth()
frame:ClearHeight()
frame:ReadWidth()
frame:ReadHeight()

-- Bounds (triggers layout pass — avoid in Update.Begin)
frame:GetBounds()   → left, top, right, bottom
frame:GetTop()      → number
frame:GetBottom()   → number
frame:GetLeft()     → number
frame:GetRight()    → number

-- Visibility
frame:SetVisible(bool)
frame:GetVisible()  → bool
frame:SetAlpha(0.0-1.0)
frame:GetAlpha()    → number
frame:SetBackgroundColor(r, g, b, a)
frame:GetBackgroundColor() → r, g, b, a

-- Layering
frame:SetLayer(n)
frame:GetLayer()   → number
frame:SetStrata(strata)
frame:GetStrata()  → string
frame:GetStrataList() → table

-- Hierarchy
frame:SetParent(parent)
frame:GetParent()  → frame
frame:GetChildren() → table
frame:GetOwner()   → owner

-- Input / Focus
frame:SetKeyFocus(bool)
frame:GetKeyFocus()  → bool
frame:SetMouseMasking(mode)
frame:GetMouseMasking() → mode
frame:SetMouseoverUnit(unitID)
frame:GetMouseoverUnit() → unitID

-- Identification
frame:GetName()   → string
frame:GetType()   → string
frame:GetEventTable() → table

-- Secure
frame:SetSecureMode('restricted')
frame:GetSecureMode() → string

-- Events
frame:EventAttach(handle, callback, label, [priority])
frame:EventDetach(handle, [callback], label, [priority], [owner])
frame:EventList()  → table
frame:EventMacroGet(handle) → macro string
frame:EventMacroSet(handle, "/macro text")  — auto sets restricted mode
```

### Text Frame Additional Methods
```lua
text:SetText(str)
text:SetFontSize(n)
text:SetFontColor(r, g, b, a)
text:SetFont(addonID, path)     — use LibEKL.UI.SetFont instead
text:SetWordwrap(bool)
```

### Texture Frame Additional Methods
```lua
tex:SetTextureAsync("addonID", "path/to/texture.png")  — own assets
tex:SetTextureAsync("Rift", iconPath)                  — Rift internal icons
```

### Canvas Frame Additional Methods
```lua
canvas:SetShape(path, fill, stroke)
canvas:GetShape() → path, fill, stroke
```

Canvas shape format:
```lua
local path = {
    {xProportional=0, yProportional=0},  -- all coords 0.0–1.0
    {xProportional=1, yProportional=0},
    -- add xControlProportional, yControlProportional for bezier curves
}
local fill = {
    type = "solid",
    r=0.1, g=0.1, b=0.1, a=1
}
-- OR gradient:
local fill = {
    type = "gradientLinear",
    transform = Utility.Matrix.Create(2, 2, math.pi/4, 0, 0),
    color = {
        {r=0.13, g=0.15, b=0.22, a=1, position=0},
        {r=0.05, g=0.07, b=0.11, a=1, position=1}
    }
}
local stroke = {r=0.4, g=0.35, b=0.18, a=1, thickness=2, cap="round", miter="miter"}
```

### RiftWindow Additional Methods
```lua
window:GetContent()     → body frame for placing children
window:SetTitle(text)
window:GetTitle()
window:GetBorder()
window:GetTrimDimensions()
window:SetController(frame)
window:GetController()
```

### UI.Native Elements
```lua
UI.Native.Bank            -- bank window
UI.Native.Auction         -- auction house window
UI.Native.BagInventory1   -- main inventory
UI.Native.MapMini         -- minimap
UI.Native.Tooltip         -- game tooltip
```

### Utility.Matrix & Utility.Event
```lua
Utility.Matrix.Create(w, h, angle, offsetX, offsetY)  → matrix (for canvas gradients)
Utility.Event.Create(addonID, eventName)               → handler, eventObject
```

---

## Additional Inspect Namespaces (from official docs)

### Inspect.Guild
```
Inspect.Guild.Bank.Coin()              → number (silver)
Inspect.Guild.Bank.List()              → {id → name}
Inspect.Guild.Bank.Detail(id|ids)      → vault detail {id, name}
Inspect.Guild.Motd()                   → string
Inspect.Guild.Rank.List()              → {rankId → rankName}
Inspect.Guild.Rank.Detail(id|ids)      → rank detail {permissions, vault access, ...}
Inspect.Guild.Roster.List()            → {memberName → status}
Inspect.Guild.Roster.Detail(name|names)→ {level, status, zone, rank, notes, ...}
```

### Inspect.Minion
```
Inspect.Minion.Minion.List()                  → minion list
Inspect.Minion.Minion.Detail(id|ids)          → minion detail
Inspect.Minion.Adventure.List()               → adventure list
Inspect.Minion.Adventure.Detail(id|ids)       → adventure detail
Inspect.Minion.Slot()                         → minion slot table
```

### Inspect.Attunement
```
Inspect.Attunement.Progress()  → {accumulated, available, needed, rested, spent}
```

### Inspect.Achievement
```
Inspect.Achievement.List()         → achievement table
Inspect.Achievement.Detail(id|ids) → achievement detail
```

### Inspect.Title
```
Inspect.Title.List()                  → {titleId → true}
Inspect.Title.Detail(id|ids)          → {id, name (gendered), gameDisplay, ...}
Inspect.Title.Category.List()         → {categoryId → true}
Inspect.Title.Category.Detail(id|ids) → category detail
```

### Inspect.Faction
```
Inspect.Faction.List()         → {id → notoriety}
Inspect.Faction.Detail(id|ids) → {categoryName, id, name, notoriety}
```

### Inspect.Role
```
Inspect.Role.List()  → {roleId → roleName}
```

### Inspect.Social
```
Inspect.Social.Friend.List()          → current friends table
Inspect.Social.Friend.Detail(name|names) → {name, level, guild, zone, status}
Inspect.Social.Ignore.List()          → ignored players table
Inspect.Social.Ignore.Detail(name|names) → {id, name, note}
```

### Inspect.Mail
```
Inspect.Mail.List()          → table of available mail
Inspect.Mail.Detail(id|ids)  → mail detail {sender, subject, body, attachments, coin, ...}
```

### Inspect.Storage
```
Inspect.Storage.Used("player"|"guild")  → current, maximum  (storage limits)
```

### Inspect.Dimension
```
Inspect.Dimension.Layout.List()         → {item → crated_bool}
Inspect.Dimension.Layout.Detail(id|ids) → {coordinates, rotation, scale, selected, ...}
```

### Inspect.Item (extended)
```
Inspect.Item.List([slot|slots])  → itemID(s)
Inspect.Item.Find(item|items)    → slot specifier(s)
```

---

## Additional Command Namespaces

### Command.Guild
```
Command.Guild.Bank.Deposit(coin)
Command.Guild.Bank.Withdraw(coin)
Command.Guild.Bank.Purchase()
Command.Guild.Motd(motd)
Command.Guild.Roster.Promote(member)
Command.Guild.Roster.Demote(member)
Command.Guild.Roster.Kick(member)
Command.Guild.Roster.Note(note)                   -- own guild note
Command.Guild.Roster.NoteOfficer(member, note)
Command.Guild.Wall.Post(post)
Command.Guild.Wall.Delete(wall)
Command.Guild.Wall.Request()
Command.Guild.Log.Request()
```

### Command.Minion
```
Command.Minion.Send(minion, adventure)
Command.Minion.Claim(adventure)
Command.Minion.Shuffle(adventure, currency)
Command.Minion.Hurry(adventure, currency)
Command.Minion.Unlock()
```

### Command.Social
```
Command.Social.Friend.Add(playerName)
Command.Social.Friend.Remove(playerName)
Command.Social.Friend.Note(playerName, note)
Command.Social.Ignore.Add(playerName)
Command.Social.Ignore.Remove(playerName)
Command.Social.Ignore.Note(playerName, note)
```

### Command.Title
```
Command.Title.Prefix(titleId|nil)  -- throttled
Command.Title.Suffix(titleId|nil)  -- throttled
```

### Command.Quest (extended)
```
Command.Quest.Track(quest|nil)     -- tracks quest, untracks others (throttled)
Command.Quest.Watch(quest, flag)   -- watch quest (hardware event required)
Command.Quest.Abandon(quest)       -- (throttled)
Command.Quest.Share(quest)         -- (hardware event required)
```

### Command.Buff
```
Command.Buff.Cancel(buff)               -- (throttled)
Command.Buff.Describe(unit, buff)       -- request detailed buff description (throttled)
```

### Command.Unit
```
Command.Unit.Menu(target)  -- creates standard context menu
```

### Command.Item (extended)
```
Command.Item.Split(source, stack)
Command.Item.Destroy(target)
Command.Item.Standard.Drag(target)
Command.Item.Standard.Drop(target)
Command.Item.Standard.Left(target)
Command.Item.Standard.Right(target)
```

### Command.Cursor
```
Command.Cursor(abilityID|itemID|itemtypeID|slotID|nil)
-- ability cursors only in insecure (non-restricted) mode
```

---

## Additional Events (from official docs)

```
Event.Addon.Load.Begin / Load.End
Event.Addon.Startup.End
Event.Addon.Shutdown.Begin / Shutdown.End
Event.Addon.SavedVariables.Load.Begin
Event.Addon.SavedVariables.Save.Begin / Save.End

Event.Combat.Heal          → (_, healInfo)
Event.Combat.Dodge         → (_, info)
Event.Combat.Parry         → (_, info)
Event.Combat.Miss          → (_, info)
Event.Combat.Resist        → (_, info)
Event.Combat.Immune        → (_, info)

Event.Unit.CastStart       → (_, unitID)
Event.Unit.CastStop        → (_, unitID)
Event.Unit.CastFailed      → (_, unitID)

Event.Chat.Npc             → NPC dialogue
Event.Chat.Notify          → screen notification

Event.Mail.Update          → mail status changed

Event.Attunement.Progress.Accumulated → (_, value)
Event.Attunement.Progress.Available   → (_, value)
Event.Attunement.Progress.Rested      → (_, value)
Event.Attunement.Progress.Spent       → (_, value)

Event.Title.Add            → (_, {titleId → true})

Event.Mouse.Move           → (_, x, y)
```

---

## LibEKL Widget Quick Reference

All widgets created via: `LibEKL.UICreateFrame("nkType", "unique.name", parent)`
All widget events via: `Command.Event.Attach(LibEKL.Events["unique.name"].EventName, ...)`

### Widget Event Summary
| Widget | Events |
|--------|--------|
| nkButton | Clicked, MouseIn, MouseOut |
| nkCheckbox | CheckboxChanged(bool) |
| nkSlider | SliderChanged(value) |
| nkCombobox | ComboChanged(itemTable) |
| nkGrid | GridFinished, LeftClick, RightClick, MouseOver, MouseOut |
| nkWindow | Moved(left,top), Closed, Shown |
| nkScrollPane | (via inner scrollbox name) ScrollboxChanged |
| nkTextField | TextfieldChanged, Enter, KeyDown, FokusLoss (typo!), Tabbed |

### nkButton
```lua
btn:SetText("label")
btn:SetFont(addonId, fontName)
btn:SetFontSize(n)
btn:SetLabelColor({r,g,b,a})    -- MUST include 'a'
btn:SetFillColor({type="solid",r,g,b,a})
btn:SetBorderColor({r,g,b,a,thickness=1})
btn:SetEffectGlow({strength=3})
btn:SetScale(0.9)
btn:SetWidth(n) / btn:SetHeight(n)
btn:SetMacro("/macro text")
```

### nkCheckbox
```lua
checkbox:SetChecked(bool, [silent])  -- silent=true skips event
checkbox:GetChecked()  → bool
checkbox:toggle()
checkbox:SetText(text)
checkbox:SetFont(addonId, fontName)
checkbox:SetFontSize(n)
checkbox:SetLabelColor({r,g,b,a})  OR  :SetLabelColor(r,g,b,a)
checkbox:SetColor({r,g,b,a})       OR  :SetColor(r,g,b,a)
checkbox:SetColorInner({r,g,b,a})
checkbox:SetActive(bool)
checkbox:SetLabelInFront(bool)
checkbox:SetRound(bool)
checkbox:SetValue(property, value) / :GetValue(property)
```

### nkSlider
```lua
slider:SetRange(from, to)
slider:AdjustValue(value)
slider:SetPrecision(n)    -- 1=integer, 0.1=one decimal
slider:SetText(formatStr) -- use %s placeholder for value display
slider:SetFont(addonId, fontName)
slider:SetFontSize(n)
slider:SetLabelColor({r,g,b,a})  OR  :SetLabelColor(r,g,b,a)
slider:SetColor({r,g,b,a})       OR  :SetColor(r,g,b,a)
slider:SetColorHighlight({r,g,b,a})
slider:SetColorInner({r,g,b,a})
slider:SetActive(bool)
slider:SetLabelWidth(n)
slider:SetWidth(n)
slider:SetValue(property, value) / :GetValue(property)
```

### nkCombobox
```lua
combo:SetSelection(items, [sort])
-- items = {{label="X", value=v, iconPath?, iconType?, texturePath?}, ...}
combo:SetSelectedValue(value)
combo:GetSelectedValue()
combo:SetSelectedLabel(label)
combo:GetSelectedLabel()
combo:SetText(label)
combo:SetFont(addonId, fontName)
combo:SetLabelWidth(n)
combo:SetWidth(n) / :SetHeight(n)
combo:SetColor({r,g,b,a})
combo:SetColorInner({r,g,b,a})
combo:SetColorSelected({r,g,b,a})
combo:SetColorBorder({r,g,b,a})
combo:SetActive(bool)
combo:SetValue(property, value) / :GetValue(property)
```

### nkGrid
```lua
grid = LibEKL.UICreateFrame("nkGrid", "name", parent)  -- NO pre-CheckEvents!
grid:Layout(cols, rows)
-- cols = { {width=80, header="Title"}, {width=28}, ... }
grid:SetFont(addonId, fontName)
grid:SetFontSize(n)
grid:SetHeaderHeight(n)
grid:SetHeaderLabelColor(r, g, b, a)   -- individual r,g,b,a NOT table
grid:SetBorderColor(r, g, b, a)
grid:SetBodyColor(r, g, b, a)
grid:SetBodyHighlightColor(r, g, b, a)
grid:SetLabelHighlightColor(r, g, b, a)
grid:SetBodySelectedColor(r, g, b, a)
grid:SetLabelSelectedColor(r, g, b, a)
grid:SetSortable(true)
grid:SetSelectable(true)
-- Cell value: "text"  OR  {value="text", color={r,g,b,a}}  OR  {value="text", key=id}
```

### nkWindow
```lua
window:GetContent()  → body frame (place children here)
window:SetTitle(text)
window:SetTitleAlign("left"|"center"|"right")
window:SetTitleFont(addonId, fontName)
window:SetTitleFontSize(n)
window:SetTitleFontColor(r, g, b, a)
window:SetDragable(bool)
window:SetCloseable(bool)
window:SetVisible(bool)
window:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)  -- MUST use TOPLEFT
```

### nkTextField
```lua
tf:SetText("text") / tf:GetText()
tf:SetWidth(n) / tf:SetHeight(n)
tf:SetInnerColor({r,g,b,a})
tf:SetFocusColor({r,g,b,a})
tf:SetBorderColor({r,g,b,a})
tf:SetValueType("number")
tf:SetMultiLine(bool)
tf:SetTabTarget(otherTf)
tf:Enter()   -- grab focus
tf:Leave()   -- release focus
-- NO SetFont, NO SetPlaceholder
-- Events: TextfieldChanged, Enter, KeyDown, FokusLoss (typo), Tabbed
```

### nkScrollPane
```lua
scroll:SetContent(widget)
scroll:SetPosition(ypos)
scroll:SetLanePosition(value) / :GetLanePosition()
scroll:SetAdjust(n)       -- wheel scroll amount (default 10)
scroll:SetColor({r,g,b,a})
scroll:SetColorHighlight({r,g,b,a})
scroll:SetColorInner({r,g,b,a})
scroll:SetWidth(n) / :SetHeight(n)
```

### nkCanvas
```lua
canvas:SetShape(path, fill, stroke)
canvas:EventAttach(handle, callback, label)
canvas:EventDetach(handle, callback, label)
canvas:EventMacroSet(handle, macro)
```

---

## LibEKL Events System

```lua
-- Single insecure exec (outside secure context)
local uuid = LibEKL.Events.AddInsecure(func, Inspect.Time.Frame(), [delayFrames])
LibEKL.Events.RemoveInsecure(uuid)

-- Periodic exec
local uuid = LibEKL.Events.AddPeriodic(func, period, [tries])
-- func returns true → stops; tries = max executions

-- Custom event namespace (for your own events)
LibEKL.Events.CheckEvents("MyModule", true)   -- returns false if duplicate!
LibEKL.eventHandlers["MyModule"]["myEvent"], LibEKL.Events["MyModule"]["myEvent"] =
    Utility.Event.Create(addonInfo.identifier, "MyModule.myEvent")
-- Fire: LibEKL.eventHandlers["MyModule"]["myEvent"](arg1, arg2)
-- Listen: Command.Event.Attach(LibEKL.Events["MyModule"]["myEvent"], handler, "label")
```

## LibEKL Coroutines

```lua
local co = coroutine.create(function()
    for i = 1, n do
        -- work
        coroutine.yield(i)  -- give control back
    end
end)
LibEKL.Coroutines.Add({
    func = co,
    counter = n,          -- completion yield value
    active = true,
    delay = 0.5,          -- optional start delay
    callBack = function() end,
    para1 = optionalArg,
    para2 = optionalArg2,
})
```

## LibEKL Performance Queue

```lua
LibEKL.Tools.Performance.AddToQueue(function()
    -- runs only when Inspect.System.Watchdog() >= 0.1
    -- lowest priority, FIFO, one per frame check
end)
```

---

## LibEKL UI Helpers

```lua
-- Fonts
LibEKL.UI.registerFont(addonId, "FontName", "fonts/Font.ttf")
LibEKL.UI.SetFont(element, addonId, "FontName")

-- Tooltips
LibEKL.UI.attachItemTooltip(frame, itemId, [callback])     -- nil itemId to detach
LibEKL.UI.attachGenericTooltip(frame, title, text)         -- nil text to detach
LibEKL.UI.attachAbilityTooltip(frame, abilityId)           -- nil abilityId to detach
LibEKL.UI.genericTooltipSetFont(addonId, fontName)
LibEKL.UI.abilityTooltipSetFont(addonId, fontName)

-- Dialogs
LibEKL.UI.confirmDialog(message, yesFunc, noFunc)
LibEKL.UI.messageDialog(message, okFunc)
LibEKL.UI.reloadDialog(title)

-- Boundary checking
LibEKL.UI.setupBoundCheck()
LibEKL.UI.showWithinBound(element, targetFrame)
LibEKL.UI.getBoundBottom()  → number
LibEKL.UI.getBoundRight()   → number
```

---

## LibEKL Unit Module

```lua
LibEKL.Unit.Init()                          -- call after Event.Unit.Availability.Full
LibEKL.Unit.GetPlayerDetails()              → {id, name, level, class, race, faction, ...}
LibEKL.Unit.GetPlayerID()                   → string
LibEKL.Unit.SetPlayerDetails(key, value)
LibEKL.Unit.GetUnitDetail(unitID, [force])  → detail table
LibEKL.Unit.GetUnitIDByType(unitType)       → table of IDs
LibEKL.Unit.GetUnitTypes(unitID)            → table of type strings
LibEKL.Unit.GetGroupStatus()                → status, count  ("single"/"group"/"raid", n)
LibEKL.Unit.Subscribe(unitType)
LibEKL.Unit.Unsubscribe(unitType)
LibEKL.Unit.GetCallingText(calling)         → localized string

-- Events (Command.Event.Attach):
LibEKL.Events.Unit.PlayerAvailable
LibEKL.Events.Unit.GroupStatus     → (status, count)
LibEKL.Events.Unit.Available       → (unitID)
LibEKL.Events.Unit.Unavailable     → (unitID)
LibEKL.Events.Unit.Change          → (unitID, changeType)
```

---

## LibEKL Inventory Module

```lua
LibEKL.Inventory.Init(updateFlag, showDebugUI)
LibEKL.Inventory.getBagItems()              → {slot → itemDetail, ...}
LibEKL.Inventory.getBankItems()             → {slot → itemDetail, ...}
LibEKL.Inventory.getAvailableSlots()        → table of slot strings
LibEKL.Inventory.getAvailableBankSlots()    → table of slot strings
LibEKL.Inventory.getQuestItems()
LibEKL.Inventory.getQuestItemSlot(typeId)   → slot or nil
LibEKL.Inventory.queryByCategory(category)  → {id → detail, ...}
LibEKL.Inventory.queryQtyById(key)          → number
LibEKL.Inventory.GetSlotByItemId(id)        → slot or nil
LibEKL.Inventory.GetAllSlotsByItemId(id)    → {slot → true, ...}
LibEKL.Inventory.querySlotByType(typeId)    → slot or nil
LibEKL.Inventory.GetAllSlotsByType(typeId)  → table of slots
LibEKL.Inventory.GetItemColor(rarity)       → {r, g, b}
LibEKL.Inventory.GetItemByKey(key)          → item or nil
LibEKL.Inventory.getAllItems()              → full item cache
LibEKL.Inventory.GetSlotContent(slot)       → item or nil
LibEKL.Inventory.findFreeBagSlot([bag])     → slot or nil
LibEKL.Inventory.findFreeBankSlot([bag])    → slot or nil
LibEKL.Inventory.findFreeVaultSlot([bag])   → slot or nil
LibEKL.Inventory.updateDB()                 — force full rescan

-- Events:
LibEKL.Events.InventoryManager.Update
LibEKL.Events.InventoryManager.SlotUpdate
```

---

## LibEKL Tools

```lua
-- Table
LibEKL.Tools.Table.IsMember(tbl, el)        → bool
LibEKL.Tools.Table.GetTablePos(tbl, el)     → index or -1
LibEKL.Tools.Table.AddValue(tbl, el)
LibEKL.Tools.Table.RemoveValue(tbl, el)
LibEKL.Tools.Table.Copy(tbl)                → deep copy
LibEKL.Tools.Table.Merge(tbl1, tbl2)        — array merge
LibEKL.Tools.Table.MergeIndexed(tbl1, tbl2) — key-value merge
LibEKL.Tools.Table.GetKeyByValue(tbl, val)  → key or nil
LibEKL.Tools.Table.GetSortedKeys(tbl)       → sorted key table
LibEKL.Tools.Table.GetSize(tbl)             → number
LibEKL.Tools.Table.GetFirstElement(tbl)     → key, value
LibEKL.Tools.Table.GetLastElement(tbl)      → key, value
LibEKL.Tools.Table.Serialize(tbl)           → string

-- Color
LibEKL.Tools.Color.HSV2RGB(h, s, v)         → r, g, b  (all 0-1)
LibEKL.Tools.Color.RGBToHex(r255,g255,b255) → "RRGGBB"
LibEKL.Tools.Color.RGBToHexColor(r,g,b)     → "RRGGBB"  (0-1 input)
LibEKL.Tools.Color.Adjust(r,g,b, factor)    → r, g, b  (clamped)

-- Math
LibEKL.Tools.Math.Round(num, decimals)      → number
LibEKL.Tools.Math.IsNaN(x)                 → bool
LibEKL.Tools.Math.Hex2number("hFF")        → 255

-- DateTime
LibEKL.Tools.DateTime.Today()                         → timestamp (midnight)
LibEKL.Tools.DateTime.IsDatePast(date)                → bool
LibEKL.Tools.DateTime.AdjustDate(date,"day"|"month",n)→ timestamp
LibEKL.Tools.DateTime.AdjustTime(time,"min",n)        → timestamp
LibEKL.Tools.DateTime.GetDaysInMonth(month, year)     → number
LibEKL.Tools.DateTime.SecondsToText(seconds)          → "2h" "30m" "45s"

-- Strings
LibEKL.strings.split(text, delim)           → table
LibEKL.strings.trim(text)                   → string
LibEKL.strings.find(source, pattern)        → pos, endPos  (nil-safe)
LibEKL.strings.left(val, delim)             → string (before first delim)
LibEKL.strings.right(val, delim, start, plain) → string (after first delim)
LibEKL.strings.leftBack(val, delim)         → string (before last delim)
LibEKL.strings.rightBack(val, delim)        → string (after last delim)
LibEKL.strings.rightRegEx(val, delim)       → string (regex match)
LibEKL.strings.startsWith(val, prefix)      → bool
LibEKL.strings.endsWith(val, suffix)        → bool
LibEKL.strings.Capitalize(text)             → string (each word capitalized)
LibEKL.strings.formatNumber(n)              → "1.234.567"

-- Graphics
LibEKL.Tools.Gfx.Rotate(frame, angle, [scale]) → transform matrix (6 values)
LibEKL.Tools.Gfx.multiplyMatrices(a, b)        → 3x3 matrix
LibEKL.Tools.Gfx.MatrixToCanvasTransform(m)    → 6-value array

-- Error
LibEKL.Tools.Error.Display("nkUI.module", "message", level)
-- level: 1=Fatal, 2=Error, 3=Warning, 4=Info

-- Settings (defaults merge)
LibEKL.Tools.Settings.UpdateSettings(defaults, savedVarsTable)

-- UUID
LibEKL.Tools.UUID()  → "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"

-- Language
LibEKL.Tools.Lang.GetLanguageShort()  → "EN" "DE" "FR" "RU"
LibEKL.Tools.Lang.GetLanguage()       → "German" "French" etc.
LibEKL.Tools.Lang.SetLanguage(lang)
LibEKL.Tools.Lang.ResetLanguage()
```

---

## LibEKL Manager (Minimap Buttons)

```lua
LibEKL.manager.RegisterButton(name, iconSource, icon, callback)
LibEKL.manager.UnregisterButton(name)
LibEKL.manager.UpdateFrame(targetFrame)  -- anchor to UI.Native.MapMini
LibEKL.manager.GetFrame()               → frame or nil
```

---

## Performance Patterns

```lua
-- Rate limit in Update.Begin
local lastUpdate = nil
Command.Event.Attach(Event.System.Update.Begin, function()
    local now = Inspect.Time.Real()
    if lastUpdate and (now - lastUpdate) < 0.1 then return end
    lastUpdate = now
    -- max runs 10x/sec
end, "nkUI.Module.Update")

-- Watchdog gate
if Inspect.System.Watchdog() < 0.1 then return end

-- GetBounds/GetWidth/GetHeight TRIGGER layout pass — avoid in Update.Begin
-- UI.Native layout queries are expensive
```

---

## Minion Stat Icon Textures (SetTextureAsync "Rift")

```
Minion_I141.dds = statEarth        (Gold)
Minion_I143.dds = statAir          (Grey)
Minion_I145.dds = statFire         (Red)
Minion_I147.dds = statWater
Minion_I149.dds = statLife
Minion_I14B.dds = statDeath
Minion_I14D.dds = statHunting
Minion_I14F.dds = statDiplomacy
Minion_I151.dds = statHarvesting
Minion_I153.dds = statDimension
Minion_I155.dds = statArtifact
Minion_I157.dds = statAssassination (Violet)
Minion_I15B.dds = Stamina           (costStamina icon)
```

Adventure detail field: `costStamina` (number) — stamina required to send minion.

---

## Fonts Available in nkUI

Montserrat, MontserratItalic, MontserratMedium, MontserratMediumItalic,
MontserratSemiBold, MontserratSemiBoldItalic, MontserratBold, MontserratExtraBold,
MontserratBlack, FiraMono, FiraMonoMedium, FiraMonoBold
