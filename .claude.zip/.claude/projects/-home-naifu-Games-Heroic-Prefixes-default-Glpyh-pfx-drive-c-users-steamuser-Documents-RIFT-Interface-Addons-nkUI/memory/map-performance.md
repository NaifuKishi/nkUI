# Map Module Performance Optimization (Feb 28, 2026)

**Status: ALL 10 PRIORITIES COMPLETE — confirmed working in-game**

## Files Modified

| File | Changes |
|------|---------|
| `modules/map/map_core.lua` | Hoisted RESOURCE_TYPE_MAP to module scope |
| `modules/map/event.lua` | Gate SystemUpdate on map visibility |
| `modules/map/map_elements.lua` | Throttle UpdateWaypointArrows (0.2s), cache InspectTimeReal |
| `Libs/LibMap/fx/fx.lua` | _fxCount counter, removed redundant GetVisible check |
| `Libs/LibMap/ui/map/map.lua` | 7 changes (see below) |

## LibMap/ui/map/map.lua Changes

1. **coordsArea in-place mutation** — no new table per movement; `coordsArea = {}` declared once as upvalue, fields mutated.

2. **mapInfo numeric cache** — added `mapInfoX1/X2/Y1/Y2` upvalues + `_updateMapInfoCache()` called from `SetMap`/`UpdateMapInfo`. All `tonumber(mapInfo.x*)` calls replaced.

3. **elementsDirty flag** — `SetCoord` sets `elementsDirty = true` instead of calling `_fctUpdateElements()` directly. Per-frame handler flushes once per frame. `_fctPan` keeps direct call (drag needs immediate feedback).

4. **elementToCheckKey reverse lookup** — `elementToCheckKey = {}` maps element ID → checkKey. `AddElement` writes both `checkIdentical[checkKey]` and `elementToCheckKey[id]`. `RemoveElement` uses O(1) lookup instead of O(n×m) pairs+IsMember scan.

5. **checkKey string via stringFormat** — replaced 4× tostring + concatenation with `stringFormat("%s:%s:%s:%s", ...)`.

6. **_fctUpdateCoord coord-change guard** — `_lastCursorCoordX/Y` locals; skips `string.format` + event fire when integer coords unchanged.

7. **_zoomLabel per-frame handler also flushes elementsDirty** — combined into existing `Event.System.Update.Begin` handler.

## Additional Changes (Feb 28, 2026 — session 2)

8. **Tile update fast path** — `_fctUpdateTiles()` now checks `tileBaseChanged` (whether `tileX`/`tileY` differ from `lastTileX`/`lastTileY`). When the base hasn't changed (~95% of frames), it only toggles visibility on edge tiles and skips all `stringFormat` + `SetTextureAsync` calls. Full texture loop only runs on boundary frames.

9. **Tile preload ring** — When the base does change, tiles one ring beyond the visible range get their textures loaded via `SetTextureAsync` while remaining hidden. This pre-caches textures before they scroll into view.

10. **Cursor coord smoothing** — `_fctUpdateCoord` changed from `mathFloor` to `mathFloor(... * 10) / 10` for 0.1-unit precision. Reduces stutter in mouse coordinate display.

**Known remaining issue:** Tile boundary crossing still causes a brief visual stutter. This is inherent to Rift's `SetTextureAsync` having a 1-2 frame delay before the new texture renders — cannot be fixed from Lua. CPU usage is good.

## fx.lua Changes

- Added `local _fxCount = 0` counter; incremented in `register`, decremented in `cancel`.
- `processFX()` returns immediately when `_fxCount == 0`.
- Removed inner redundant `details.frame:GetVisible()` check (was nested inside outer visibility check).

## Key Bug During Implementation

`attempt to call global '_updateMapInfoCache' (a nil value)` — caused by Python file-write scripts not persisting between runs (each script re-read the file fresh, discarding previous in-memory changes). Fixed by using the Edit tool directly to add: (a) `local mapInfoX1, mapInfoX2, mapInfoY1, mapInfoY2 = 0, 0, 0, 0` in VARIABLES block, and (b) `local function _updateMapInfoCache()` in LOCAL METHODS section.

## Lesson: Tab Characters in Lua Files

`Libs/LibMap/ui/map/map.lua` uses `\t` tabs throughout. The Edit tool fails on indented blocks. Use Python heredoc + `.replace()` with `repr()` inspection for precise edits in this file.
