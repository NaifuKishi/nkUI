# Phase 1A Browse Tab - Complete Test Plan

## Pre-Test Setup

1. Load nkUI addon in RIFT
2. Navigate to an Auction House NPC
3. Open nkUI settings → Auctions window
4. Click "Browse" tab

## Quick Verification Checklist

1. **Grid Visible**: 10 columns (Icon, Item, Seller, Stack, Bid, Buyout, Unit, vs. Vendor, My Price, Expires)
2. **Search Works**: Type item name, click Search, grid populates
3. **Rarity Filters**: Click C/U/R/E/Rel/T/P buttons, grid filters instantly
4. **Sort**: Click column headers, sort persists when switching tabs
5. **My Price**: Shows player's own auction prices where applicable
6. **Vendor Ratio**: Red if >5x, normal color if lower
7. **Buyout Coloring**: Green if below market low
8. **No Console Errors**: Check /console for any errors

## Detailed Test Scenarios

### Test 1: Grid Display & Search
- [ ] Search for "cloth"
- [ ] Verify 10 columns populate
- [ ] Verify data aligns under headers
- [ ] Prices formatted with commas

### Test 2: Rarity Filters
- [ ] Click "R" (Rare) button
- [ ] Verify only rare items shown
- [ ] Button appears highlighted
- [ ] Click again to deactivate

### Test 3: Multiple Rarity Filters
- [ ] Click "E" and "T" simultaneously
- [ ] Verify Epic and Transcendent items shown
- [ ] Both buttons highlighted
- [ ] Other buttons dimmed

### Test 4: Name Search Live Filter
- [ ] Clear search
- [ ] Type "mote"
- [ ] Verify instant filter (no click needed)
- [ ] Type " of" to narrow further
- [ ] Clear to reset

### Test 5: New Scan with Search
- [ ] Type "planarite"
- [ ] Click "Search Now"
- [ ] Verify scan completes
- [ ] Grid populates with results
- [ ] Search text persists

### Test 6: Sort Persistence
- [ ] Click "Unit" column header
- [ ] Verify sort ascending
- [ ] Click again → verify sort descending
- [ ] Switch to different tab and back
- [ ] Verify sort preserved
- [ ] (Optional) Relog and verify saves

### Test 7: My Price Column
- [ ] Post item at AH (if you have one)
- [ ] Scan and search for your item
- [ ] Verify "My Price" shows unit price
- [ ] Other items show "-"

### Test 8: Vendor Ratio Analysis
- [ ] Look for items with >5x vendor ratio
- [ ] Verify text appears red
- [ ] Normal items appear in standard color

### Test 9: Buyout Undercut Detection
- [ ] Look for green-colored buyout prices
- [ ] Verify these are below market lows
- [ ] Normal-colored buyouts are at/above market

### Test 10: Rarity Color Codes
- [ ] Common: Grey
- [ ] Uncommon: Green
- [ ] Rare: Blue
- [ ] Epic: Purple
- [ ] Relic: Orange
- [ ] Transcendent: Gold
- [ ] Primalist: Pink-red

### Test 11: Expiry Time Format
- [ ] Verify "Xh Ym" for times >1 hour
- [ ] Verify "Xm" for times <1 hour
- [ ] No seconds displayed

### Test 12: Empty Results
- [ ] Search for nonsensical term "xyzabc123"
- [ ] Click Search
- [ ] Verify grid empty, no errors

### Test 13: Large Result Sets
- [ ] Search for common item (wood, ore)
- [ ] Scan large dataset
- [ ] Verify smooth population
- [ ] Sorting works without lag

### Test 14: Filter + Sort Together
- [ ] Filter to "U" (Uncommon)
- [ ] Sort by "Bid"
- [ ] Verify both work together
- [ ] Change filter to "R", sort preserved

### Test 15: Search Edge Cases
- [ ] Uppercase search "CLOTH"
- [ ] Search with spaces "  cloth  "
- [ ] Verify case-insensitive and trimmed

### Test 16: Console Checks
- [ ] Monitor `/console` throughout tests
- [ ] No red error messages
- [ ] No nil-pointer warnings
- [ ] No function undefined errors

## Performance Check
- [ ] Scan completes in <5 seconds
- [ ] Grid populates immediately
- [ ] Rarity filters instant
- [ ] Name search instant
- [ ] Sorting instant for 1000 items
- [ ] No UI freezing

## Known Limitations (Expected)
- Column resizing not implemented (fixed widths)
- Column reordering not implemented
- Right-click context menu not yet implemented
- Item preview tooltip not yet implemented

## Pass/Fail
- [ ] **PASS** - All tests green
- [ ] **FAIL** - See console errors and test number above
