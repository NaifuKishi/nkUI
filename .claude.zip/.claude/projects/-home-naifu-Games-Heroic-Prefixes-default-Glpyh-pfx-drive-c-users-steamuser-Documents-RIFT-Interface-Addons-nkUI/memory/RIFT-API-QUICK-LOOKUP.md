# RIFT API Quick Lookup Guide
## For Claude to use when coding nkUI features

**Full reference:** `memory/rift-api-reference.md`

---

## Before writing ANY code:

1. **Startup sequence** → Always use `Event.Addon.SavedVariables.Load.End`, then `Event.Unit.Availability.Full`
2. **SetPoint anchors** → MUST be: TOPLEFT/TOPCENTER/TOPRIGHT/CENTERLEFT/CENTER/CENTERRIGHT/BOTTOMLEFT/BOTTOMCENTER/BOTTOMRIGHT/CENTERBOTTOM (NOT TOP/BOTTOM/LEFT/RIGHT)
3. **LibEKL widgets** → Events via `Command.Event.Attach(LibEKL.Events[name].EventName, ...)` — NEVER `frame:EventAttach`
4. **Inspect calls** → Wrap in `pcall()` if data might be unavailable
5. **Key events** → `function(self, _, key)` — key is 3rd parameter

---

## Quick API Lookup Checklists

### "I need to query player/unit/item data"
- **Player details** → `LibEKL.Unit.GetPlayerDetails()` (returns {id, name, level, class, ...})
- **Any unit** → `Inspect.Unit.Detail(unitID)` or `LibEKL.Unit.GetUnitDetail(unitID)`
- **Inventory** → `LibEKL.Inventory.getBagItems()` returns {slot → itemDetail, ...}
- **Find item by category** → `LibEKL.Inventory.queryByCategory("misc quest")`
- **Quest info** → `Inspect.Quest.Detail(questKey)` or `Inspect.Quest.List()`

### "I need to do something that affects game state"
- **Move item** → `Command.Item.Move(fromSlot, toSlot)` (wrap in pcall)
- **Place auction bid** → `Command.Auction.Bid(auction, bid, [quantity], [callback])`
- **Post auction** → `Command.Auction.Post(item, time, bid, buyout, [partial], [callback])`
- **Accept quest** → Game handles via UI, no API
- **Send mail** → `Command.Mail.Send(mail, [callback])`
- **Set waypoint** → `Command.Map.Waypoint.Set(x, y)`
- **Reload UI** → `Command.Script.Reload()` (after keybind changes)

### "I need to react to game events"
- **Player/unit changed** → `Event.Unit.Detail.*` (health, mana, zone, etc.)
- **Buff added/removed** → `Event.Buff.Add/Remove`
- **Cast started/stopped** → `Event.Unit.CastStart/CastStop`
- **Combat damage** → `Event.Combat.Damage`
- **Quest accepted** → `Event.Quest.Accept`
- **Every frame** → `Event.System.Update.Begin` (check watchdog!)
- **Mouse/key input** → `Event.UI.Input.Mouse.Left.Click` etc. via `frame:EventAttach`

### "I need to create a UI element"
- **Create frame** → `LibEKL.UICreateFrame("nkFrame", "unique.name", parent)`
- **Create text** → `LibEKL.UICreateFrame("nkText", "unique.name", parent)` + `:SetText()`
- **Create button** → `LibEKL.UICreateFrame("nkButton", "unique.name", parent)` + `:SetText()`, `:SetLabelColor({r,g,b,a})`
- **Create checkbox** → `LibEKL.UICreateFrame("nkCheckbox", "unique.name", parent)`
- **Create slider** → `LibEKL.UICreateFrame("nkSlider", "unique.name", parent)` + `:SetRange(min, max)`
- **Create dropdown** → `LibEKL.UICreateFrame("nkCombobox", "unique.name", parent)` + `:SetSelection(items)`
- **Create table** → `LibEKL.UICreateFrame("nkGrid", "unique.name", parent)` (NO pre-CheckEvents!)
- **Create window** → `LibEKL.UICreateFrame("nkWindow", "unique.name", parent)` + `:GetContent()` for body

### "I need to listen to a widget event"
- **Button clicked** → `Command.Event.Attach(LibEKL.Events["widgetName"].Clicked, handler, "label")`
- **Checkbox changed** → `Command.Event.Attach(LibEKL.Events["widgetName"].CheckboxChanged, handler, "label")`
- **Slider changed** → `Command.Event.Attach(LibEKL.Events["widgetName"].SliderChanged, handler, "label")`
- **Combo changed** → `Command.Event.Attach(LibEKL.Events["widgetName"].ComboChanged, handler, "label")`
- **Grid cell clicked** → `Command.Event.Attach(LibEKL.Events["widgetName"].LeftClick, handler, "label")`
- **Window moved** → `Command.Event.Attach(LibEKL.Events["widgetName"].Moved, handler, "label")`

### "I need to do expensive work"
- **Rate limit in Update.Begin** → Track `Inspect.Time.Real()` and skip if < 0.1s elapsed
- **Multi-frame work** → Use `LibEKL.Coroutines.Add(co)` with `coroutine.yield()`
- **Low priority work** → `LibEKL.Tools.Performance.AddToQueue(func)` (only runs when watchdog >= 0.1)
- **Periodic tasks** → `LibEKL.Events.AddPeriodic(func, period, tries)`

### "I need to handle special cases"
- **Secure mode checks** → `Inspect.System.Secure()` returns bool
- **Performance budget** → `Inspect.System.Watchdog()` — skip if < 0.1
- **Language detection** → `LibEKL.Tools.Lang.GetLanguageShort()` returns "EN"/"DE"/"FR"/"RU"
- **Get screen bounds** → `LibEKL.UI.getBoundRight()`, `getBoundBottom()`
- **UUID generation** → `LibEKL.Tools.UUID()`
- **Date/time** → `LibEKL.Tools.DateTime.Today()`, `.SecondsToText(seconds)` etc.

---

## Common Patterns to Avoid

❌ **DON'T:**
- `Inspect.Unit.Detail()` before `Event.Unit.Availability.Full` fires
- `SetPoint("TOP", ...)` — use `TOPCENTER` instead
- Attach to `Event.Unit.Availability.Full` without detaching after init
- Pre-call `LibEKL.Events.CheckEvents(name, true)` for widget names
- Call `frame:GetBounds()` in `Event.System.Update.Begin` (triggers layout pass)
- Use `frame:EventAttach` with LibEKL custom events
- Forget alpha in `nkButton:SetLabelColor({r,g,b,a})` — all 4 params required
- Create widget events with nkGrid — it auto-registers internally

✅ **DO:**
- Wrap Inspect calls in `pcall()`
- Cache Rift API functions locally: `local inspectTimeReal = Inspect.Time.Real`
- Use `LibEKL.Tools.Settings.UpdateSettings()` for SavedVar defaults
- Rate-limit with `Inspect.Time.Real()` timestamps
- Check `Inspect.System.Watchdog() >= 0.1` before expensive ops
- Use LibEKL widgets instead of raw `UI.CreateFrame`
- Test in-game after any UI changes (layout, event handling)

---

## When Stuck

1. **Check `memory/rift-api-reference.md`** for exact signatures
2. **Search nkUI codebase** for similar usage patterns in `modules/*/`
3. **Read the LibEKL widget source** in `Libs/LibEKL/ui/` (not the full reference, the actual .lua)
4. **Check MEMORY.md** for project-specific constraints
5. **Test in-game** — many edge cases only appear during gameplay

---

## File Locations

- **API Reference** → `/memory/rift-api-reference.md`
- **LibEKL Widget API** → `/memory/libEKL-widget-api.md`
- **Widget sources** → `/Libs/LibEKL/ui/*/`
- **nkUI modules** → `/modules/*/` (study existing code)
- **Theme/constants** → `/theme.lua`, `/main.lua`
