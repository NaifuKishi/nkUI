# RIFT API – Erweiterungsmöglichkeiten für nkUI

Analysiert am 2026-02-28. Vollständige API-Referenz: https://www.seebs.net/rift/live/

---

## Hochpriorität – Große Features

### Minion Manager *(einzigartig für RIFT, kaum von Addons abgedeckt)*
**APIs:** `Inspect.Minion.Minion.List/Detail`, `Inspect.Minion.Adventure.List/Detail`, `Inspect.Minion.Slot()`, `Command.Minion.Send/Claim/Hurry/Shuffle/Unlock`
**Events:** `Event.Minion.Adventure.Change`, `Event.Minion.Minion.Change`

Minion.Detail Felder: `id`, `name`, `level`, `rarity`, `stamina`, `staminaMax`, `experienceAccumulated`, `experienceNeeded` + 13 Stat-Felder: `statAir`, `statArtifact`, `statAssassination`, `statDeath`, `statDimension`, `statDiplomacy`, `statEarth`, `statExploration`, `statFire`, `statHarvesting`, `statHunting`, `statLife`, `statWater`

Adventure.Detail Felder: `id`, `name`, `mode` (available/working/finished), `duration`, `completion` (UNIX), `minion`, `reward`, `rewardQuality`, `costStamina`, `costAventurine`, `costCredit`, `hurryAventurine`, `hurryCredit` + 13 Stat-Bonus-Felder

**Feature-Ideen:**
- Alle Minions mit Level, XP, Ausdauer, 13 Stat-Balken
- Abenteuer-Slots mit Countdown-Timer
- Automatische Empfehlung des passenden Minions (Stat-Matching)
- One-Click: alle fertigen Abenteuer abholen
- Benachrichtigung wenn Abenteuer abgeschlossen
- Ausdauer-Regenerations-Tracker
- Seltenheits-farbige Minion-Karten

---

### Achievement Tracker
**APIs:** `Inspect.Achievement.List/Detail`, `Inspect.Achievement.Category.List/Detail`, `Command.Achievement.Watch`
**Events:** `Event.Achievement.Complete`, `Event.Achievement.Update`

Achievement.Detail Felder: `id`, `name`, `description`, `icon`, `category`, `complete`, `score`, `alliance`, `previous`, `sort`, `title`, `watch`
Requirement Felder: `type`, `name`, `count`, `countDone`, `complete`, `id`
Requirement-Typen: `achievement`, `artifactset`, `discover`, `event`, `quest`, `tradeskill`

**Feature-Ideen:**
- Fortschrittsbalken pro Anforderung (`countDone/count`)
- Watched-Achievement-Panel mit Live-Updates
- Achievement-Ketten visualisieren (über `previous`-Feld)
- Popup bei Abschluss
- Achievement-Punkte-Gesamt-Anzeige
- Leaderboard innerhalb einer Gilde

---

### Guild Manager
**APIs:** `Inspect.Guild.Roster.List/Detail`, `Inspect.Guild.Rank.List/Detail`, `Inspect.Guild.Bank.List/Detail/Coin`, `Inspect.Guild.Motd`, `Command.Guild.Roster.*`, `Command.Guild.Bank.*`, `Command.Guild.Motd`, `Command.Guild.Log.Request`, `Command.Guild.Wall.*`
**Events:** `Event.Guild.Roster.Add/Remove`, `Event.Guild.Roster.Detail.*`, `Event.Guild.Rank`, `Event.Guild.Bank.Change/Coin`, `Event.Guild.Motd`, `Event.Guild.Log`, `Event.Guild.Wall`

Roster.Detail Felder: `id`, `name`, `level`, `rank`, `note`, `noteOfficer`, `status` (online/mobile/nil), `zone`, `logout` (UNIX), `score`
Log Entry Felder: `type`, `source`, `target`, `achievement`, `coin`, `count`, `item`, `level`, `rank`, `xp` (27 Event-Typen)

**WICHTIG:** `Command.Guild.Log.Request()` und `Command.Guild.Wall.Request()` sind asynchron → Antwort kommt über Event, nicht sofort!

**Feature-Ideen:**
- Vollständiges Roster-Fenster (sortierbar nach Level, Rank, letzte Online-Zeit, Zone, Score)
- Guild-Log Viewer (27 Event-Typen: Promotions, Bank-Transaktionen, XP-Gewinne…)
- Guild Wall (Pinnwand) – lesen, posten, löschen
- MOTD-Editor und Anzeige-Widget
- Bank-Übersicht (Vault-Namen, Guthaben)
- Officer-Notizen direkt im Roster bearbeiten
- Online/Offline-Zähler Badge

---

## Mittlere Priorität – Panel-Erweiterungen

### PvP Stats Panel
**APIs:** `Inspect.Pvp.History()` → `favorLifetime`, `killLifetime`, `killMonth`, `killWeek`, `killToday`; `Inspect.Pvp.Prestige()` → `rank`, `accumulated`, `needed`
**Events:** `Event.Pvp.History.Favor`, `Event.Pvp.History.Kill.Today`, `Event.Pvp.Prestige.Accumulated`, `Event.Pvp.Prestige.Rank`

**Feature-Ideen:**
- Prestige-Rank mit Fortschrittsbalken
- Kill-Zähler: heute / Woche / Monat / Lifetime
- Session-Kill-Counter (Delta seit Login)
- Prestige Rank-Up Benachrichtigung
- Warfront-Kontext via `Inspect.Zone.Detail` type-Feld = `"warfront"`

---

### Currency Tracker
**APIs:** `Inspect.Currency.List/Detail`, `Inspect.Currency.Category.List/Detail`
**Events:** `Event.Currency`

Currency.Detail Felder: `id`, `name`, `icon`, `category`, `stack`, `stackMax`

**Feature-Ideen:**
- Alle Währungen mit Cap-Balken (`stack/stackMax`)
- Warnung wenn Währung am Cap
- Gewinn pro Session (Delta aus SavedVars)
- Verlauf über Sessions hinweg

---

### Friends Panel (Erweiterung der bestehenden Social-Anzeige)
**APIs:** `Inspect.Social.Friend.List/Detail`, `Inspect.Social.Ignore.List/Detail`, `Command.Social.Friend.Add/Remove/Note`, `Command.Social.Ignore.Add/Remove/Note`
**Events:** `Event.Social.Friend`, `Event.Social.Ignore`

Friend.Detail Felder: `id`, `name`, `note`, `calling`, `guild`, `level`, `race`, `status` (online/afk/nil), `zone`

**Feature-Ideen:**
- Erweitertes Friends-Panel mit Zone, Level, Klassen-Icon
- Freund-Notiz-Editor
- "Freund ist online"-Benachrichtigungs-Popup
- Freunde in der aktuellen Zone hervorheben

---

### Mail Inbox
**APIs:** `Inspect.Mail.List/Detail`, `Command.Mail.Open/Send/Take/Delete/Return/Pay/Spam`
**Events:** `Event.Mail`

Mail.Detail Felder: `id`, `subject`, `from`, `body` (nur nach Open), `attachments`, `cod`, `expire`, `read`, `spam`

**WICHTIG:** `Inspect.Interaction()` muss `mail = true` zurückgeben (Nähe zum Briefkasten nötig)!

**Feature-Ideen:**
- Ungelesene Mail-Badge auf dem Manager-Button
- "Alle Anhänge nehmen"-Button
- COD-Mail-Alarm
- Ablauf-Warnung für alte Mails
- Mail-Kompositions-UI

---

### Attunement (Planar Attunement) XP-Bar
**APIs:** `Inspect.Attunement.Progress()` → `accumulated`, `needed`, `rested`, `available` (unausgegebene Punkte), `spent`
**Events:** `Event.Attunement.Progress.Accumulated/Available/Rested/Spent`

**Feature-Ideen:**
- PA-XP-Bar mit Rested-XP-Overlay analog zur normalen XP-Bar
- Unausgegebene PA-Punkte Badge/Alert
- PA-XP/Stunde Tracker

---

### Fraktion/Notoriety Tracker
**APIs:** `Inspect.Faction.List/Detail` → `id`, `name`, `categoryName`, `notoriety`
**Events:** `Event.Faction.Notoriety`

**Feature-Ideen:**
- Fortschrittsbalken aller Fraktionen
- Tier-Up Benachrichtigung
- Sortierbar nach Fortschritt oder Kategorie
- Notoriety-Gewinn pro Session

---

## Kampf-Analyse

### Damage Meter / DPS Tracker
**Events:** `Event.Combat.Damage`, `Event.Combat.Heal`, `Event.Combat.Death`, `Event.Combat.Miss/Dodge/Resist/Immune`, `Event.Chat.Notify` (Boss-Warnungen), `Event.Chat.Npc`

Combat.Damage Felder: `caster`, `casterName`, `target`, `targetName`, `ability`, `abilityName`, `damage`, `damageAbsorbed`, `damageBlocked`, `damageIntercepted`, `damageModified`, `overkill`, `crit`, `type` (life/death/air/earth/fire/water)

**WICHTIG:** `Event.Combat.Parry` ist deprecated – nicht verwenden!

**Feature-Ideen:**
- DPS/HPS Tracking für Gruppe
- Schaden nach Element-Typ aufgeschlüsselt
- Death Recap (letzte N Schadensereignisse vor dem Tod)
- Boss-Emotes / NPC-Sprache loggen
- Interrupt/Resist Tracker für Boss-Fähigkeiten

---

## Kleine Ergänzungen (Niedrige Priorität)

### Title Browser
**APIs:** `Inspect.Title.List/Detail`, `Inspect.Title.Category.List/Detail`, `Command.Title.Prefix/Suffix`
**Events:** `Event.Title.Add`

Title.Detail Felder: `id`, `gameMale`, `gameFemale`, `nameMale`, `nameFemale`, `prefix`

**Feature-Ideen:** Titel-Browser mit Kategorie-Filter, Prefix/Suffix setzen, Unlock-Benachrichtigung

---

### Queue Status Widget
**APIs:** `Inspect.Queue.Status(name)`, `Command.Queue.Handler(func)`
**Events:** `Event.Queue.Status`

**Feature-Ideen:** LFG/Warfront-Queue-Anzeige, Position, geschätzte Wartezeit, Auto-Accept Handler

---

### Charakter-Stats Panel
**API:** `Inspect.Stat()` → alle Stats mit `*Unbuffed`-Varianten
**Events:** `Event.Stat`

Felder: `strength`, `dexterity`, `intelligence`, `wisdom`, `endurance`, `resistLife/Death/Fire/Water/Earth/Air`, `armor`, `powerAttack`, `critAttack`, `hit`, `powerSpell`, `critSpell`, `critPower`, `block`, `dodge` (je mit `*Unbuffed`)

**Feature-Ideen:** Stats-Panel mit gebufften/ungebufften Vergleich, Buff-Beitrag pro Stat

---

### Kontextabhängige UI Auto-Show
**API:** `Inspect.Interaction()` → `auction`, `bank`, `guildbank`, `mail` (boolean)
**Events:** `Event.Interaction`

**Feature-Ideen:** Bank-Panel automatisch beim Bankier öffnen, Mail-Panel beim Briefkasten, AH beim Auktionator

---

### Sonstige kleine Features
| Feature | API | Aufwand |
|---|---|---|
| Shard-Name Anzeige | `Inspect.Shard()` → `name`, `pvp`, `rp` | Sehr klein |
| Zone-Typ Erkennung | `Inspect.Zone.Detail()` → `type` (instance/warfront/nil) | Sehr klein |
| Addon CPU Profiler | `Inspect.Addon.Cpu()` | Klein |
| Server-Side Storage | `Command.Storage.Set/Get/List` | Mittel |

---

## Inter-Addon Messaging (nkUI-zu-nkUI Sync)
**APIs:** `Command.Message.Send(target, type, id, data, callback)`, `Command.Message.Broadcast(type, id, message, targets)`, `Command.Message.Accept/Reject`, `Inspect.Message.Accept.Check/List`
**Events:** `Event.Message.Receive`

**WICHTIG:** Send-Target muss nearby, in Guild, in Party/Raid oder hat kürzlich eine Nachricht geschickt. Broadcast ist unzuverlässig (UDP-artig).

**Feature-Ideen:**
- DPS-Daten im Raid teilen
- Waypoints und Notizen zwischen Spielern synchronisieren
- Geteilte Achievement Watch-Lists im Raid

---

## API Constraints & Gotchas

- `Inspect.Interaction()` muss geprüft werden vor `Command.Mail.*`, `Command.Guild.Bank.*`, `Command.Auction.*`
- `Command.Guild.Log.Request()` und `Command.Guild.Wall.Request()` sind **asynchron** → Daten kommen über Events
- `Command.Storage.*` für Guild-Scope benötigt Guild-Permission "Write to Guild Addon Storage"
- `Command.Message.Send` Target muss nearby/guild/party oder hat kürzlich geschrieben
- `Command.Message.Broadcast` ist unzuverlässig
- `Inspect.Auction.Detail` benötigt vorherigen `Command.Auction.Scan` (asynchron via `Event.Auction.Scan`)
- `Command.Dimension.Layout.Place` nur in eigener Dimension möglich
- `Event.Combat.Parry` ist **deprecated**

---

## Priorisierte Umsetzungsreihenfolge

1. **Minion Manager** – einzigartig, vollständige API, hoher Nutzwert
2. **Guild Manager** – täglich genutzt, sehr umfangreiche API
3. **Achievement Tracker** – ergänzt Quest-System sinnvoll
4. **PvP Stats Panel** – einfach, gut sichtbar
5. **Currency Tracker** – kleine Ergänzung zur Lower Bar
6. **Attunement XP Bar** – Ergänzung zur bestehenden XP-Bar
7. **Mail Inbox Badge** – kleiner Aufwand, hoher Nutzwert
8. **Damage Meter** – größerer Aufwand, aber sehr gefragt
