# LibEKL Widget API Reference
## Learned from in-game testing during Phase 1A (Feb 26, 2026)

**RULE #1: Always read the widget's .lua source in Libs/LibEKL/ui/ before writing any code that uses it.**

---

## Event Attachment Pattern

LibEKL widgets create CUSTOM events via `Utility.Event.Create`, stored under `LibEKL.Events[widgetName]`.
These are NOT Rift frame events. Two completely different systems:

```lua
-- Rift frame events (Event.UI.*) → frame:EventAttach
frame:EventAttach(Event.UI.Input.Mouse.Left.Up, handler, "label")

-- LibEKL custom events → Command.Event.Attach
Command.Event.Attach(LibEKL.Events["nkUI.myWidget"].SomeEvent, handler, "label")
```

Never use `frame:EventAttach` with a LibEKL custom event — it will error with
"Incorrect function usage: Parameters: (Frame, table, function, string)".

---

## nkGrid

**Source:** `Libs/LibEKL/ui/grid/grid.lua`

### Column definition format
```lua
-- CORRECT: uses 'header', not 'label'
{ width = 80, header = "Column Title" }
{ width = 28 }  -- no header = empty/texture col
```

### Styling methods (all take individual r,g,b,a NOT a table)
```lua
grid:SetFont(addonId, fontName)
grid:SetBodyColor(r, g, b, a)
grid:SetBorderColor(r, g, b, a)
grid:SetHeaderLabelColor(r, g, b, a)
grid:SetBodyHighlightColor(r, g, b, a)
grid:SetLabelHighlightColor(r, g, b, a)
grid:SetSortable(true)          -- REQUIRED for header-click sorting
grid:SetSelectable(true)
grid:SetHeaderHeight(n)
grid:SetFontSize(n)
```

### NO SetColor, NO SetTextColor — these don't exist on nkGrid.

### Cell value formats
```lua
-- Plain string (default label color)
"text"

-- Colored cell
{ value = "text", color = { r = 1, g = 0, b = 0, a = 1 } }

-- Cell with extra key (e.g. row ID)
{ value = "text", key = someId }

-- Texture cell (col must have textureType defined, or omit for auto)
"path/to/texture.png"
```

### Events (all via Command.Event.Attach)
```lua
Command.Event.Attach(LibEKL.Events[GRID_NAME].GridFinished, handler, "label")
Command.Event.Attach(LibEKL.Events[GRID_NAME].LeftClick, handler, "label")
Command.Event.Attach(LibEKL.Events[GRID_NAME].RightClick, handler, "label")
Command.Event.Attach(LibEKL.Events[GRID_NAME].MouseOver, handler, "label")
Command.Event.Attach(LibEKL.Events[GRID_NAME].MouseOut, handler, "label")
-- NO ColumnSort event — sorting is internal, hook via oFunc pattern on grid:Sort
```

### Sort persistence pattern
```lua
local oSort = grid.Sort
function grid:Sort(col, sortOrder)
    oSort(self, col, sortOrder)
    -- save col and sortOrder to SavedVars here
end
```

### CheckEvents — DO NOT PRE-REGISTER
The grid internally calls `LibEKL.Events.CheckEvents(name, true)` when creating
its inner nkFrame. If you pre-call it with the same name, it returns false (fatal
duplicate) and the inner nkFrame returns nil → grid is nil at first method call.

```lua
-- WRONG: causes "Duplicate name" fatal, grid = nil
LibEKL.Events.CheckEvents("nkUI.my.grid", true)
grid = LibEKL.UICreateFrame("nkGrid", "nkUI.my.grid", parent)

-- CORRECT: just create it directly
grid = LibEKL.UICreateFrame("nkGrid", "nkUI.my.grid", parent)
```

---

## nkTextField

**Source:** `Libs/LibEKL/ui/form/textfield.lua`

### Styling methods
```lua
textField:SetWidth(n)
textField:SetHeight(n)
textField:SetInnerColor({ r, g, b, a })       -- background
textField:SetFocusColor({ r, g, b, a })        -- border color on focus
textField:SetBorderColor({ r, g, b, a })       -- border color at rest (if supported)
textField:SetText("text")
textField:GetText()
textField:SetValueType("number")               -- coerce to number on GetConvertedText
textField:SetMultiLine(true)
textField:SetTabTarget(otherTextField)
textField:Enter()                              -- grab focus
textField:Leave()                              -- release focus / optionally restore value
```

### NO SetFont, NO SetPlaceholder — these don't exist.

### Events (all via Command.Event.Attach)
```lua
Command.Event.Attach(LibEKL.Events["widgetName"].TextfieldChanged, handler, "label")
Command.Event.Attach(LibEKL.Events["widgetName"].Enter, handler, "label")
Command.Event.Attach(LibEKL.Events["widgetName"].KeyDown, handler, "label")
Command.Event.Attach(LibEKL.Events["widgetName"].FokusLoss, handler, "label")  -- typo in LibEKL
Command.Event.Attach(LibEKL.Events["widgetName"].Tabbed, handler, "label")
```

---

## nkButton

**Source:** `Libs/LibEKL/ui/button/button.lua`

### SetLabelColor — MUST include alpha field
```lua
-- CORRECT: table must have r, g, b, AND a
btn:SetLabelColor({ r = 1, g = 0.5, b = 0, a = 1 })

-- WRONG: missing 'a' → button.lua line 65 passes color.a directly to SetFontColor
-- SetFontColor does not accept nil for alpha
btn:SetLabelColor({ r = 1, g = 0.5, b = 0 })   -- a is nil → ERROR
```

### Other methods
```lua
btn:SetText("label")
btn:SetFont(addonId, fontName)
btn:SetFillColor({ type = "solid", r, g, b, a })
btn:SetBorderColor({ r, g, b, a, thickness = 1 })
btn:SetEffectGlow({ strength = 3 })
btn:SetScale(0.9)
btn:SetWidth(n)
btn:SetHeight(n)
```

---

## nkFrame

**Source:** `Libs/LibEKL/ui/default/frame.lua`

Plain transparent container. NO SetColor method.
Use as parent container only. Style children individually.

```lua
local frame = LibEKL.UICreateFrame("nkFrame", "name", parent)
frame:SetPoint(...)
frame:SetWidth(n)
frame:SetHeight(n)
-- That's about it for styling. No SetColor.
```

---

## General Lua Rules (re-confirmed)

### Forward references — locals are NOT globals
```lua
-- WRONG: toggleRarity calls applyFilterAndSort before it's defined
local function toggleRarity() applyFilterAndSort() end
local function applyFilterAndSort() ... end

-- CORRECT: define callees before callers
local function applyFilterAndSort() ... end
local function toggleRarity() applyFilterAndSort() end
```

### Local variable scope
```lua
-- WRONG: function closes over nil, not the local declared later
function auction.isAtAH() return atAuctionHouse end   -- line 366
local atAuctionHouse = false                          -- line 372 — TOO LATE

-- CORRECT: declare before first use
local atAuctionHouse = false
function auction.isAtAH() return atAuctionHouse end
```

---

## BEFORE WRITING ANY NEW WIDGET CODE

Read these files first:
- `Libs/LibEKL/ui/grid/grid.lua` — nkGrid
- `Libs/LibEKL/ui/form/textfield.lua` — nkTextField
- `Libs/LibEKL/ui/button/button.lua` — nkButton
- `Libs/LibEKL/ui/default/frame.lua` — nkFrame
- `Libs/LibEKL/ui/window/window.lua` — nkWindow
- `Libs/LibEKL/ui/pane/tabPane.lua` — nkTabPane
- `Libs/LibEKL/ui/pane/scrollpane.lua` — nkScrollPane
