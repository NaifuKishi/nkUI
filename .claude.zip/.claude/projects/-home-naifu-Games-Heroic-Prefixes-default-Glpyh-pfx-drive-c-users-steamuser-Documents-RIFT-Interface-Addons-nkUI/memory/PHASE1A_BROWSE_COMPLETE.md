# Phase 1A: Browse Tab Implementation - COMPLETE

**Status:** IMPLEMENTATION COMPLETE & COMMITTED (Feb 26, 2026)
**Commit:** 1d3a9ec

## Summary

Full implementation of the auction house Browse tab with searchable, filterable, sortable item grid and player price comparison. All code has been syntax-validated.

## Features Implemented

### Grid Display (10 Columns)
1. **Icon** (28px) - Item texture
2. **Item Name** (200px) - Colored by rarity
3. **Seller** (100px) - Listing seller name
4. **Stack** (40px) - Quantity per listing
5. **Bid** (80px) - Current bid value
6. **Buyout** (80px) - Buy-it-now price (green if below market low)
7. **Unit Price** (80px) - Calculated per-item cost
8. **Vendor Ratio** (65px) - Price vs vendor (red if >5x)
9. **My Price** (80px) - Lowest unit price of own auctions
10. **Expiry** (60px) - Time remaining on listing

### Filtering & Search
- **Rarity Filter Bar**: 7 buttons (C, U, R, E, Rel, T, P) toggle rarities on/off
  - Empty table = show all rarities
  - Selected rarities highlight in darker tint
  - Re-filters grid on each toggle
- **Search by Name**: Text field with Enter key support and live filtering
- **Sort Persistence**: Remembers selected column and ascending/descending order

### Price Analysis
- Compares buyout prices to recent market lows (green if undercut)
- Shows vendor ratio with red highlighting for extreme markups (>5x)
- Displays player's own listing prices in dedicated column
- Pulls data from auction.getPriceSummary() and auction.ownAuctions cache

## Technical Details

### Files Modified

| File | Changes |
|---|---|
| `auction.lua` | Expose helpers, add browseSearchPending state, add ownAuctions cache, update initFunc |
| `auction-browse.lua` | Full 360-line implementation with grid, filters, search, sorting |
| `settings.lua` | Add `browse = { sortCol=7, sortAsc=true, rarityFilter={} }` to defaults |
| `localizationEN.lua` | Add `colMyPrice`, `browseHint` |
| `localizationDE.lua` | Add `colMyPrice`, `browseHint` |
| `localizationFR.lua` | Add `colMyPrice`, `browseHint` |

### Public Functions Added to auction Module

```lua
auction.makeBtn(name, parent, label, w, h)          -- Create styled button
auction.formatExpiry(seconds)                        -- Format remaining time
auction.isAtAH()                                     -- Check if at auctioneer
auction.isBrowseSearchPending()                      -- Check scan status
auction.setBrowseSearchPending(flag)                 -- Set scan status
auction.refreshOwnAuctions()                         -- Populate ownAuctions cache
auction.buildBrowseTab(browseFrame)                  -- Build browse tab UI
auction.ownAuctions                                  -- Cache: [itemType] = lowestUnitPrice
```

### Architecture

**Module-level State:**
- `browseRows`: Raw auction data before filtering (rebuilt on each scan)
- `grid`: nkGrid widget instance
- `searchInput`: nkTextField for name search
- `rarityBtns`: Table of 7 rarity toggle buttons [0..6]

**Data Flow:**
1. User presses "Search Now" → `Command.Auction.Scan({ type = "search" })`
2. Rift returns auction IDs in Event.Auction.Scan event
3. Handler checks `auction.isBrowseSearchPending()` and:
   - Calls `auction.refreshOwnAuctions()` → caches player's listings
   - Calls `populateBrowseGrid(auctions)` → processes all IDs
4. populateBrowseGrid:
   - Iterates auction IDs, fetches detail + item metadata
   - Calculates unit price, vendor ratio, formats for display
   - Builds row objects with parallel sort keys for numeric columns
   - Calls `applyFilterAndSort()` to display
5. User filters/searches → `applyFilterAndSort()`:
   - Applies rarity filter (check rarityFilter table)
   - Applies name search (case-insensitive substring match)
   - Sorts by selected column (numeric or string)
   - Calls `grid:SetCellValues()` to refresh display

**Sort Handling:**
- Persists sortCol and sortAsc to SavedVars
- Grid emits ColumnSort event on header click
- Sorts built into applyFilterAndSort for rarity/search changes
- Numeric columns (bid, buyout, unit, ratio, myPrice) use sortKeys parallel table
- String columns (name, seller, stack, expiry) use direct string comparison

**Grid Layout:**
- Search bar: 28px top with 280px input + 80px button
- Rarity buttons: 30px with 7×40px buttons
- Main grid: Remaining space filled with scrollable 30-row visible area

## Rarity Color Scheme

| Rarity | Label | Color |
|---|---|---|
| 0 | C (Common) | Grey (0.8, 0.8, 0.8) |
| 1 | U (Uncommon) | Green (0.1, 0.9, 0.1) |
| 2 | R (Rare) | Blue (0.0, 0.5, 1.0) |
| 3 | E (Epic) | Purple (0.6, 0.1, 0.9) |
| 4 | Rel (Relic) | Orange (1.0, 0.5, 0.0) |
| 5 | T (Transcendent) | Gold (1.0, 0.9, 0.2) |
| 6 | P (Primalist) | Pink-red (0.9, 0.4, 0.4) |

## Testing Checklist

- [ ] Load addon in RIFT at auction house
- [ ] Open nkUI → Auctions → Browse tab
- [ ] Verify grid shows 10 columns with headers
- [ ] Type item name in search, press Enter → scan executes, grid populates
- [ ] Verify rarity buttons toggle on/off (visual feedback)
- [ ] Click column headers → sort persists on relog
- [ ] Verify "My Price" column shows own listing prices
- [ ] Check buyout coloring (green if < market low)
- [ ] Check vendor ratio coloring (red if > 5x)
- [ ] Toggle rarity off/on → grid filters without rescanning

## Known Limitations & Future Work

- Phase 1B: My Auctions tab (list player's own listings)
- Phase 2: Prices tab (price history and trend graphs)
- Phase 3: Post tab (most complex - post items for sale UI)
- Phase 4: Settings pane (scan depth, display options)

## Performance Notes

- Scan processing happens async via LibEKL.Coroutines (doesn't freeze UI)
- Filter/sort reapplied only when needed (input change, rarity toggle)
- Grid recycles rows internally via nkGrid widget
- Own auctions cache queried once per scan (local table, no API calls)
