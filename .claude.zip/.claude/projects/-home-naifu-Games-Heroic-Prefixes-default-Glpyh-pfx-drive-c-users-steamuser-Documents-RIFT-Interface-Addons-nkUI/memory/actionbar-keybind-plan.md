# Action Bar Keybind Display Implementation Plan

**Status:** Design Complete (Feb 25, 2026)

## Overview

Implement **cosmetic keybind labels** on action bar icons. The RIFT API has no keybinding support, so keybinds execute via the native hidden Rift bars. nkUI displays the assigned key as a text overlay for visual reference.

## Why This Approach?

- **RIFT API Constraint:** No `Inspect.Keybinding` or `Command.Keybinding` exists
- **Secure System Limitation:** `EventMacroSet()` only works on mouse-click events, not key events
- **Solution:** Cosmetic display + optional manual text entry in macro dialog

## Architecture

### Key Concepts

1. **Keybind Label** - small nkText overlay on each action icon (bottom-left corner)
2. **Key Capture Dialog** - fullscreen transparent frame that captures key press via `SetKeyFocus(true)`
3. **SavedVar Extension** - add `keyBind` string to slot data structure
4. **Modifier State Tracking** - global flag tracking shift/ctrl/alt press state

### Data Structure

```lua
-- In nkUISetup.modules.actionBars.bars[playerName].roles[roleId].bars[barIndex].slots[buttonIndex]:
{
    itemType = "ability" | "item" | "macro",
    itemKey = "...",
    macroIcon = "...",
    macroCD = { type, key },
    keyBind = "1" | "F5" | "Alt+2" | nil  -- NEW: display label
}
```

## Implementation Phases

### Phase 1: SavedVar Extension
- **File:** `modules/actionbar/actionbar.lua`
- Add `keyBind = nil` to `data.defaultBar` slot template
- Extend role/bar initialization to include keyBind field

### Phase 2: KeyBind Label on Icons
- **File:** `modules/actionbar/actionicon.lua`
- Create `keyBindLabel` (nkText) lazily, positioned bottom-left of icon
- Add `frame:SetKeyBind(key)` function to show/hide and set text
- Call from `frame:SetItem()` to populate on load
- Call from `frame:ClearItem()` to hide on clear

### Phase 3: Key Capture Dialog
- **File:** `modules/actionbar/keybindDialog.lua` (NEW)
- Fullscreen transparent frame with `SetKeyFocus(true)`
- Listen on `Frame.Event:KeyDown` to capture key string
- Display instruction: "Press a key for slot X... (Esc to cancel)"
- Callback with captured key string; hide on Escape

**Modifier Key Handling:**
- Track shift/ctrl/alt state via global flags set on Key.Down/Up
- Compose label like `"Shift+1"` by combining stored modifiers with new key

### Phase 4: Trigger from Action Icon
- **File:** `modules/actionbar/actionicon.lua`
- Add permanent `Event.UI.Input.Key.Down/Up` listener to track modifier state
- Change right-click behavior: if **Shift held** → open keybind capture; else → clear slot
- Or: add optional "KB" hotspot badge visible in non-combat mode

### Phase 5: Populate/Clear Integration
- **File:** `modules/actionbar/actionbar.lua`
- In `actionBar:Populate()`: read `slots[n].keyBind`, call `frame:SetKeyBind(kb)`
- In `actionBar:Clear()`: call `frame:SetKeyBind(nil)`

### Phase 6: Macro Edit Dialog Extension (Optional)
- **File:** `modules/actionbar/macroEditDialog.lua`
- Add "Keybind" text input field to existing dialog
- Pre-fill with current `keyBind` value
- Allow player to type label directly instead of using capture dialog

### Phase 7: Documentation & Localization
- **Files:** `locales/localizationEN.lua` (and other languages)
- Update action bar description tooltip
- Change from "no keybindings possible" to "keybind labels for reference"
- Add help text for Shift+RClick and keybind capture dialog

## Files to Modify/Create

| File | Type | Changes |
|---|---|---|
| `modules/actionbar/keybindDialog.lua` | **NEW** | Key capture dialog implementation |
| `modules/actionbar/actionicon.lua` | Modify | Add keyBindLabel, SetKeyBind(), modifier tracking, shift+right-click |
| `modules/actionbar/actionbar.lua` | Modify | Extend defaultBar, call SetKeyBind in Populate/Clear |
| `modules/actionbar/macroEditDialog.lua` | Modify | Add optional keybind text field |
| `RiftAddon.toc` | Modify | Add keybindDialog.lua to RunOnStartup |
| `locales/localizationEN.lua` | Modify | Update tooltip text |
| `locales/localizationDE.lua` | Modify | German translations |
| `locales/localizationFR.lua` | Modify | French translations |

## API References Used

### RIFT Key Events
- `Event.UI.Input.Key.Down` / `Frame.Event:KeyDown` - key press capture
- `Event.UI.Input.Key.Up` / `Frame.Event:KeyUp` - key release (for modifier tracking)
- `Frame:SetKeyFocus(true/false)` - grab/release keyboard focus
- `Event.UI.Input.Key.Focus.Gain/Loss` - focus change notification

### nkUI Patterns
- `LibEKL.UICreateFrame()` - create UI elements
- `LibEKL.UI.SetFont()` - set font on text element
- `internalFunc.checkSecureAction()` - guard against combat execution
- SavedVar storage in `data.actionBarSetup.roles[role].bars[barIndex].slots[buttonIndex]`

## Testing Checklist

- [ ] Keybind label renders on icon with correct font/size/color
- [ ] Shift+RClick opens key capture dialog (non-combat only)
- [ ] Key capture dialog closes on Escape
- [ ] Captured key saved to SavedVars
- [ ] Label updated immediately after capture
- [ ] Label persists on relog
- [ ] Shift+RClick still clears on non-shift click
- [ ] Modifier state tracking accurate (shift/ctrl/alt compose)
- [ ] Works on all 5 action bars (main, stance, left, right, rightScreen)
- [ ] Works with abilities, items, and macros
- [ ] Macro edit dialog keybind field works (optional)
- [ ] Localization strings display correctly
- [ ] No memory leaks (label created lazily, destroyed with frame)

## UX Flow

1. **Setup:** Player opens action bar, places ability on slot 1
2. **Bind Label:** Shift+RClick slot → capture dialog appears
3. **Capture:** Player presses "1" → dialog closes, label shows "1" on icon
4. **Reference:** Icon now shows player which native Rift bar slot to map to
5. **Execution:** Player presses native keybind (e.g., `1` on native bar) → Rift bar executes
6. **Persistence:** On relog, label "1" re-renders automatically from SavedVars

## Notes

- **Display-only:** Keybind labels are cosmetic reference only
- **Actual execution:** Happens through native Rift bars (hidden) or click macros
- **No automation risk:** Can't abuse keybinds to automate combat (API limitation)
- **Modifier composition:** Shift+1, Ctrl+F5, Alt+3 etc. supported via key state tracking
- **Optional:** Macro edit dialog keybind field is nice-to-have for direct text entry

## Future Enhancements (Out of Scope)

- Keybind profile export/import
- Automatic native bar generation (too risky, manual mapping safer)
- Custom label editor (allow names like "AoE Heal" instead of just keys)
- Global keybind conflict checker
