# nkWardrobe → nkUI Migration - COMPLETE

## Phase 1-4: Core Implementation Summary

**Status:** All core functionality implemented and integrated.

### Files Created (3 new files)
1. `modules/wardrobe/wardrobe.lua` - Core logic (equip mover, SavedVars, tooltip integration)
2. `modules/wardrobe/wardrobeUI.lua` - Configuration dialog (simplified from 1243 lines of EnKai code)
3. `modules/lowerbar/wardrobe.lua` - Lowerbar set switcher element (dropdown with left/right-click)

### Files Modified (15 files)
- **RiftAddon.toc** - Added 3 new module files + 2 character-scoped SavedVars (nkUIWardrobe, nkUIWardrobeBackup)
- **settings/settings.lua** - Added `wardrobe = { activate = true }` default
- **locales/localizationEN.lua** - Added complete `wardrobe` section with all UI strings + soul icons
- **main.lua** - Added `/nkui wardrobe` slash command handler, wardrobeInit() call
- **modules/lowerbar/lowerbar.lua** - Added `lowerBar.lowerBarWardrobe()` call
- **8 lowerbar modules** - Updated width divisor (/8 → /9) and adjusted position multipliers:
  - **roles.lua**: width*2 → width*3
  - **experience.lua**: width*3 → width*4
  - **faction.lua**: -(width*3) → -(width*4)
  - **vitality.lua**: -(width*2) → -(width*3)
  - **currency.lua**: -width → -(width*2)
  - **fps.lua, social.lua, location.lua**: Width divisor only
- **modules/onebag/itemCategories.lua** - Added `oneBag.getWardrobeSetForItem()` function
- **modules/onebag/onebag.lua** - Modified `bagContent()` to check wardrobe categories (items in sets appear ONLY in set-named category)

### Key Features Implemented
✅ Equipment set storage & management (create, rename, copy, delete)
✅ Current equipment capture (reads all 20 slots)
✅ Equipment equipping via coroutine-based item mover (handles temp slots for equipped items)
✅ Bank operations (move to/from bank)
✅ Lowerbar set switcher with left/right-click (left = dropdown, right = config dialog)
✅ Item tooltip integration (shows set membership)
✅ Character-scoped SavedVars (each character has independent sets)
✅ OneBag set-named categories (items in sets categorized by set name)
✅ Migration from nkWardrobe (auto-imports sets on first load)
✅ Simplified config dialog (no linked sets, roles, rebuff/kAlert, yell, settings)
✅ Slash command: /nkui wardrobe

### Features Omitted (as requested)
❌ Set linking to roles / auto role switching
❌ Master/linked set concept
❌ Set switcher bar (floating button with sub-buttons)
❌ Settings pane items (button config, border, direction, scale, lock, nkPanel, modern button)
❌ nkRebuff / kAlert / yell integrations
❌ nkPanel plugin
❌ Tutorial wizard

### Design Decisions Finalized
- **SavedVars Scope:** Character-scoped (matches nkWardrobe behavior)
- **Config Access:** `/nkui wardrobe` slash + right-click on lowerbar element
- **OneBag Display:** Items in wardrobe sets appear ONLY in set-named category (not in normal category)

### Lowerbar Layout
Added as 9th module between FPS and Roles:
```
Social | FPS | Wardrobe | Roles | Experience | ... | Faction | Vitality | Currency | Location
   0   |  1  |    2     |   3   |     4      |     |   -4    |   -3    |   -2     |   -1
```

All module widths now = (canvas_width - timeDate_width) / 9

## Phase 5: Not Yet Done
- [ ] German locale (localizationDE.lua) - needs translation
- [ ] French locale (localizationFR.lua) - needs stubs or translation
- [ ] Manual section in settings/manual.lua
- [ ] In-game testing (startup, equipping, lowerbar interaction, OneBag categories, migration)

## Notes
- Fixed recursive function in wardrobeUI.lua line ~533 (internalFunc.wardrobeShowUI calling itself)
- EnKai → LibEKL API translation complete (all widget names compatible)
- Config dialog simplified significantly (removed ~600 lines of EnKai code for omitted features)
- Wardrobe module independent of other nkUI modules (no cross-dependencies except langTexts, data, uiElements)
