# nkUI Project Memory

## RIFT API Complete Reference (Mar 2026)
Full API reference compiled from official docs + codebase analysis.
→ **`memory/rift-api-reference.md`** — use this to avoid guessing any API call

Covers: Inspect.* / Command.* / Event.* exact signatures, frame methods,
SetPoint anchors, LibEKL widget methods + events, startup order, performance patterns.

## RIFT API Feature Plan
Vollständige Analyse aller RIFT API-Namespaces und Erweiterungsmöglichkeiten für nkUI.
→ Siehe: `memory/rift-api-features.md`

**Priorisierte Umsetzungsreihenfolge:**
1. Minion Manager (einzigartig, vollständige API)
2. Guild Manager (Roster, Log, Wall, MOTD, Bank)
3. Achievement Tracker (Requirement-Fortschrittsbalken)
4. PvP Stats Panel (Prestige, Kill-Counts)
5. Currency Tracker (Cap-Warnung, Session-Delta)
6. Attunement XP Bar (PA-XP + Rested)
7. Mail Inbox Badge (kleiner Aufwand, hoher Nutzwert)
8. Damage Meter (DPS/HPS Tracking)

---

## Map Module Performance Optimization (Feb 28, 2026)
**Status: ALL 10 PRIORITIES COMPLETE — confirmed working in-game**
→ Siehe: `memory/map-performance.md`

**Summary of changes:**
- `map_core.lua`: RESOURCE_TYPE_MAP hoisted to module scope
- `event.lua`: SystemUpdate gated on map visibility
- `map_elements.lua`: UpdateWaypointArrows throttled (0.2s + next() guard)
- `fx.lua`: _fxCount counter for O(1) skip when no FX; redundant GetVisible removed
- `Libs/LibMap/ui/map/map.lua`: coordsArea in-place, mapInfo numeric cache, elementsDirty flag, elementToCheckKey reverse lookup, checkKey via stringFormat, _fctUpdateCoord coord-change guard

**Key lesson:** `map.lua` uses `\t` tabs — Edit tool fails on indented blocks. Use Python heredoc + `.replace()`.

---

## Auction House Module (Feb 26, 2026)
**Status: Phase 1A working. Phase 1B next.**
→ Key files: `modules/auction/auction*.lua`

**CRITICAL: LibEKL Widget API Rules** → `memory/libEKL-widget-api.md`
- ALL LibEKL widget events use `Command.Event.Attach`, NOT `frame:EventAttach`
- `nkGrid`: `header` field (not `label`); `SetSortable(true)`; no `SetColor`
- `nkButton.SetLabelColor`: takes `{r,g,b,a}` table — must include `a`
- Never pre-call `LibEKL.Events.CheckEvents(name, true)` for widget names
- Local variables must be declared BEFORE functions that reference them

---

## Keybind Labels Feature (Feb 26, 2026)
**Status: COMPLETE with improvements. Ready for in-game testing.**

Key files:
- `modules/actionbar/keybindDialog.lua` - Key capture dialog (SetKeyFocus pattern)
- `modules/actionbar/actionicon.lua` - Label display (TOPLEFT, layer 3)
- `modules/actionbar/actionbar.lua` - SavedVar + Populate()

Improvements: label at TOPLEFT (not BOTTOMRIGHT), exclusive keybinding (auto-clears duplicates), Command.Script.Reload() on save.

---

## IMPORTANT: Rift API Constraints

### Event.UI.Input.Key.Down — key is 3rd param
```lua
frame:EventAttach(Event.UI.Input.Key.Down, function(self, _, key) ... end, "name")
-- Special: "Shift", "Control", "Alt"; regular keys lowercase ("q", "1", "space")
```

### SetPoint Valid Anchor Points
Valid: `TOPLEFT TOPCENTER TOPRIGHT CENTERLEFT CENTER CENTERRIGHT BOTTOMLEFT BOTTOMCENTER BOTTOMRIGHT CENTERBOTTOM`
Invalid: `BOTTOM TOP LEFT RIGHT` — use CENTERBOTTOM, TOPCENTER, etc.

### nkWindow: MUST use TOPLEFT anchor for the window frame itself

---

## Earlier Optimization Work (Feb 24, 2026)

- **Phase 1**: Fixed 6 duplicate event handler names, `setupConfirmDialog()` helper, `STROKE_BORDER` constant (~700 LOC consolidated)
- **Phase 2a**: Color/glow/canvas path constants in theme.lua, font + gradient helpers in main.lua (~95 LOC consolidated)
- **Tiled Map Restoration**: Recovered experimental tiled map code from commit 78df570 (kept commented/disabled)

---

## Testing Setup
- Busted framework in `spec/` directory
- Mocks in `spec/setup.lua`
- Run: `busted` or `busted --verbose`
→ See `TESTING.md` and `TESTING_QUICKSTART.md`
