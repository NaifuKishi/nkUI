# nkUI Auction House Expansion Plan

**Date:** 2026-02-25
**Base file:** `modules/auction/auction.lua` (714 lines, schemaVer 1)
**Goal:** Replicate BananAH feature set from scratch in nkUI patterns using LibEKL — no code reuse from BananAH.

---

## Context

The existing nkUI auction module has a working browse/search tab, a ring-buffer price snapshot engine (30 snapshots per item, per shard), and a full-scan coroutine pipeline. Three tabs are stubs: Post, My Auctions, Prices. BananAH provides a full AH management suite (batch posting, competition scoring, price analytics, own-auction management). This plan describes how to implement equivalent functionality natively in nkUI.

---

## Phase 0 — File Split (prerequisite, no user-visible changes)

The single 714-line file must be split before adding new tabs.

**New file layout:**
```
modules/auction/
    auction.lua          — namespace, data model, scan engine, public API (keep, trim tab stubs)
    auction-browse.lua   — Browse tab (refactored from auction.lua)
    auction-post.lua     — Post tab + posting queue engine
    auction-mine.lua     — My Auctions tab + competition scoring
    auction-prices.lua   — Prices tab + snapshot analytics
    auction-settings.lua — Settings pane injected into main nkUI settings window
```

**RiftAddon.toc** — add to `RunOnStartup` after `"modules/auction/auction.lua"`:
```
"modules/auction/auction-browse.lua",
"modules/auction/auction-post.lua",
"modules/auction/auction-mine.lua",
"modules/auction/auction-prices.lua",
"modules/auction/auction-settings.lua",
```

All new files follow the standard module header (local addonInfo, privateVars = ..., cache all API refs at top).

---

## Phase 1A — Browse Tab Enhancements

**File:** `auction-browse.lua` (moved from auction.lua)

### New features

**Rarity filter bar** — 7 toggle nkButton row below search bar (one per rarity 0–6), coloured borders using:
```lua
local RARITY_COLORS = {
    [0]={r=0.6,g=0.6,b=0.6}, [1]={r=0.1,g=0.8,b=0.1}, [2]={r=0.2,g=0.4,b=1.0},
    [3]={r=0.6,g=0.1,b=0.9}, [4]={r=1.0,g=0.5,b=0.0}, [5]={r=1.0,g=0.8,b=0.0},
    [6]={r=0.3,g=0.0,b=0.3},
}
```
Filter stored in `auction.browseRarityFilter = {}` (upvalue). Applied inside scan result handler.

**Bid column** — added between Stack and Buyout. Reads `d.bid` from `Inspect.Auction.Detail()`. Shows `"—"` if 0 or nil.

**My Price column** — last column, populated from `auction.ownAuctions[itemType]` (lowest own unit price, populated by My Auctions refresh). Empty if no own listing.

**Sort persistence** — store `auction.browseSortCol` / `auction.browseSortDir`; re-apply after each search via `grid:SetSort(col, dir)`.

**Event rename** — handler renamed to `"nkUI.Auction.Browse.Scan"` (was ambiguous).

---

## Phase 1B — My Auctions Tab

**File:** `auction-mine.lua`

### Data flow
`auction.refreshMyAuctions()` called on tab open, after cancel, and on:
- `Event.Auction.Auction.Remove` → `"nkUI.Auction.Mine.Remove"`
- `Event.Auction.Auction.Add`    → `"nkUI.Auction.Mine.Add"`

Scans all auctions where `detail.own == true`. Lazy competition scan (targeted search) if data > 5 min stale.

Also populates `auction.ownAuctions` (key = itemType, value = lowest own unit buyout) for Browse tab's My Price column.

### Competition scoring
```lua
-- score = floor(unitBuyout * 100 / referenceAvg); 100 = at avg price
local SCORE_TIERS = {
    { max =  60, r=0.0, g=0.9, b=0.9 },  -- cyan:   very cheap
    { max =  85, r=0.0, g=0.8, b=0.0 },  -- green:  below avg
    { max = 100, r=0.9, g=0.9, b=0.0 },  -- yellow: near avg
    { max = 120, r=1.0, g=0.5, b=0.0 },  -- orange: above avg
    { max = math.huge, r=0.9, g=0.1, b=0.1 }, -- red: overpriced
}
```

### Grid columns
Icon | Item | Stack | Buyout | Unit | Expires | Score | Below (# cheaper listings)

### Filter bar (above grid)
- 5 nkCheckbox for score tier visibility
- nkTextField "Max below" (numeric) — client-side filter, no rescan

### Cancel actions
- `[Cancel Selected]` — `pcall(Command.Auction.Cancel, selectedID)`
- `[Cancel All]` — `LibEKL.UI.confirmDialog` → coroutine with `Inspect.System.Watchdog() >= 0.1` gate per cancel, calls `refreshMyAuctions()` on completion

---

## Phase 2 — Prices Tab

**File:** `auction-prices.lua`

Reads existing ring-buffer data from `nkUIAuction[shard].items`. No new scan triggered. Client-side search filter (string.find plain).

### Grid columns
Icon | Item | Scans | Last Lo | Mean | Trend | Vendor Ratio | Last Scan

### Trend calculation (from 2 most-recent snapshots)
```lua
-- delta = snap1.lo - snap2.lo; pct = delta / snap2.lo
-- pct > 0.05  → "↑" (orange)
-- pct < -0.05 → "↓" (green — cheaper = good)
-- else        → "→" (grey)
```

### Vendor ratio colouring
- `>= 5.0` → `data.theme.labelColor` (gold)
- `>= 2.0` → `{r=0.6, g=0.8, b=0.3}` (green)
- `>= 1.0` → `{r=0.7, g=0.7, b=0.7}` (grey)
- `< 1.0`  → `{r=0.9, g=0.2, b=0.2}` (red)

### Population
Coroutine iterates `shardData.items`, yields every 50 items. `[Clear All Data]` button with `LibEKL.UI.confirmDialog` guard.

---

## Phase 3 — Post Tab (most complex)

**File:** `auction-post.lua`

### Layout (two-panel)
```
Left (280px): Inventory list (recycling-bin rows, rarity filter, right-click hide)
Right (600px): Per-item config + queue grid
```

### Data model additions — schemaVer bump to 2

In `auction.lua` → `initShard()`:
```lua
-- nkUIAuction._postConfig[itemType] = { stackSize, auctionLimit, postIncomplete,
--   duration, priceModel, priceModelParam, undercutType, undercutAmount, autoPost }
-- nkUIAuction._hidden[itemType] = true   (account-wide item visibility)
```
`_` prefix ensures no collision with shard name keys.

### Inventory panel
- `Inspect.Item.List("inventory")` aggregated by itemType
- Recycling-bin pattern (mirrors questlog ui-entry.lua)
- Hidden items (`nkUIAuction._hidden`) excluded
- Row right-click: "Hide this item" / "Show all hidden"
- `Event.Item.Inventory` → `"nkUI.Auction.Post.InventoryChanged"` → refresh

### Config panel (loaded on row click)
Falls back: per-item config → category default → global default

**Price models:**

| Model    | Calculation |
|----------|-------------|
| `vendor` | `vendor * param` (param = multiplier) |
| `mean`   | `summary.avg` from ring buffer |
| `median` | Sort snapshot lo-prices, return middle |
| `stdev`  | `avg - N * stdev` (outlier-filtered floor, N = param) |
| `fixed`  | `param` (copper amount) |

**Undercut logic:**
```lua
-- marketLo from browseAuctionData or summary.lastLo fallback
-- absolute: mathMax(1, marketLo - undercutAmount)
-- relative: mathMax(1, mathFloor(marketLo * (1 - undercutAmount)))
```

Bid amount = `price * (bidPct / 100)` where `bidPct` from settings.

`[Save Config]` → writes to `nkUIAuction._postConfig[itemType]`
`[Set as Category Default]` → writes partial config to `nkUISetup.modules.auction.categoryDefaults[category]`

### Posting queue
`auction.postQueue` — list of `{ itemType, slotId, stackSize, price, duration, status }`

Coroutine: one post per tick, watchdog-gated, re-verify slot before each post (slot may have moved).

Duration stored as seconds: 43200 (12h) / 172800 (48h) / 259200 (72h).

Queue grid columns: Item | Stack | Price | Status (grey/green/red)

`[Start]` / `[Stop]` / `[Clear Queue]` buttons.

> **⚠ Pitfall:** `Command.Auction.Post` may require a restricted secure context. If so, the post button's parent context needs `context:SetSecureMode("restricted")` — reference `actionbar.lua` for this pattern. Verify early.

---

## Phase 4 — Settings Pane

**File:** `auction-settings.lua`

Implements `settingsUI.uiConfigTabAuction(name, parent)` following the exact pattern of `settings-tabTooltip.lua`. Injected into `internalFunc.setupUI()` in `settings.lua` as a new tab.

**Settings exposed in UI:**
- Auto-open with AH (checkbox)
- Show price in tooltip (checkbox)
- Bid % of buyout (slider 50–100)
- Undercut type (dropdown: absolute / relative)
- Undercut amount (nkTextField)
- Default price model (dropdown)
- Default duration (dropdown)
- Price history depth / scan depth (slider)
- Auto-scan on AH open (checkbox) ← Phase 5 setting

---

## Phase 5 — Scan Enhancements (nice-to-have)

**File:** `auction.lua` (additive changes)

- **Bid tracking in snapshots:** extend accumulator with `bidLo`/`bidHi`; snapshot gains these fields (schemaVer → 3, purely additive)
- **Auto-scan on AH open:** extend `Event.Interaction` handler — if `autoScan = true` and `lastScan` older than `autoScanInterval` hours, fire `AddInsecure(internalFunc.ahScanDialog, Inspect.Time.Frame(), 3)` (3-frame delay for AH to load)

---

## Data Model Summary

### `nkUIAuction` (SavedVariable, account scope)
```lua
nkUIAuction[shardName] = {
    schemaVer    = 2,       -- bumped from 1
    lastScan     = number,
    items = {
        [itemType] = { name, icon, rarity, vendor, category,  -- category NEW
                       snapshots = { {t, lo, hi, count} × 30 },
                       snapshotHead }
    }
}
nkUIAuction._postConfig = { [itemType] = { ... } }  -- NEW, account-wide
nkUIAuction._hidden     = { [itemType] = true }     -- NEW, account-wide
```

### New `nkUISetup.modules.auction` settings keys
```lua
bidPct              = 75,
undercutType        = "absolute",
undercutAmount      = 100,
defaultPriceModel   = "mean",
defaultDuration     = 172800,  -- 48h in seconds
defaultStackSize    = 1,
categoryDefaults    = {},
autoScan            = false,
autoScanInterval    = 4,
```

---

## New Localization Keys (EN reference, same keys needed in DE/FR)

To be added to `langTexts.auction` block in all three locale files:

```
Phase 1: colBid, colMyPrice, colBelow, colScore, btnCancelAuction, btnCancelAll,
         confirmCancelAll, filterRarity
Phase 2: colTrend, colMean, colScans, colLastLo, colLastScan, colVendorRatio,
         trendUp("↑"), trendDown("↓"), trendStable("→"), btnClearData, confirmClearData
Phase 3: tabPostInventory, tabPostConfig, tabPostQueue, btnAddToQueue, btnStartPosting,
         btnStopPosting, btnClearQueue, btnSaveConfig, btnSetDefault, btnHideItem,
         btnShowHidden, labelStackSize, labelAuctionLimit, labelPostInc, labelDuration,
         dur12h, dur48h, dur72h, labelPriceModel, modelVendor, modelMean, modelMedian,
         modelStDev, modelFixed, labelUndercutType, undercutAbsolute, undercutRelative,
         labelUndercutAmt, queueEmpty, queuePosting, queueDone,
         statusPending, statusPosted, statusFailed
Phase 4: settingsBidPct, settingsUndercutType, settingsScanDepth, settingsAutoScan,
         settingsAutoScanInterval
```

---

## Events Summary

| Phase | Event | Handler name |
|-------|-------|-------------|
| Existing | `Event.Auction.Scan` (scan dialog) | `"nkUI.Auction.Scan"` |
| 1A | `Event.Auction.Scan` (browse) | `"nkUI.Auction.Browse.Scan"` |
| 1B | `Event.Auction.Auction.Remove` | `"nkUI.Auction.Mine.Remove"` |
| 1B | `Event.Auction.Auction.Add` | `"nkUI.Auction.Mine.Add"` |
| 3 | `Event.Item.Inventory` | `"nkUI.Auction.Post.InventoryChanged"` |
| 5 | `Event.Interaction` (auto-scan) | `"nkUI.Auction.Interaction.AutoScan"` |

---

## Critical Files

| File | Changes |
|------|---------|
| `modules/auction/auction.lua` | Trim tab stubs, expose tab builder hooks, schemaVer → 2, `_postConfig`/`_hidden` init |
| `modules/auction/auction-browse.lua` | New — Phase 1A browse tab |
| `modules/auction/auction-mine.lua` | New — Phase 1B my auctions tab |
| `modules/auction/auction-prices.lua` | New — Phase 2 prices tab |
| `modules/auction/auction-post.lua` | New — Phase 3 post tab |
| `modules/auction/auction-settings.lua` | New — Phase 4 settings pane |
| `RiftAddon.toc` | Add 5 new files to RunOnStartup |
| `settings/settings.lua` | Add new auction settings keys; inject auction settings tab |
| `locales/localizationEN.lua` | New localization keys |
| `locales/localizationDE.lua` | Mirror EN keys (to translate) |
| `locales/localizationFR.lua` | Mirror EN keys (to translate) |

**Pattern references to consult:**
- Recycling-bin row pattern → `modules/questlog/ui-entry.lua`
- Settings tab injection → `settings/settings-tabTooltip.lua`
- Secure context pattern → `modules/actionbar/actionbar.lua`
- `LibEKL.UI.confirmDialog` pattern → any questlog settings dialog

---

## Implementation Order

```
Phase 0 → 1A → 1B → 2 → 3 → 4 → 5
```

Phase 0 is a prerequisite for all others. Phases 1A and 1B can be developed together. Phase 3 depends on Phase 1B (`auction.ownAuctions`) and Phase 2 (price calculation helpers). Phase 4 last (needs all settings keys finalized). Phase 5 is additive and independent.
