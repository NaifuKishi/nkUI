# Map Module Performance Optimization Plan

## Context

The nkUI map module is a performance-critical system that renders a tiled map with potentially hundreds of elements (POIs, quest markers, resource nodes, rare mobs, waypoints, player/group units, animated rifts). After thorough analysis of 10+ source files across nkUI and LibMap, multiple performance bottlenecks have been identified — from unnecessary per-frame work to redundant table allocations in hot paths.

The goal is to minimize computations and updates, ensure off-screen elements are properly hidden, and eliminate wasteful operations that run every frame regardless of need.

---

## Identified Issues & Fixes

### PRIORITY 1: Eliminate Per-Frame Work When Map is Hidden

**Problem:** Both `Event.System.Update.Begin` handlers run every frame regardless of whether the map is visible.

**Files:**
- `modules/map/event.lua:75-101` — `mapEvents.SystemUpdate`
- `Libs/LibMap/events/events.lua:103-171` — `_fctUpdateHandler` (processFX, periodic events)
- `Libs/LibMap/ui/map/map.lua:481-485` — zoom label hide handler

**Fix:**
- In `mapEvents.SystemUpdate` (event.lua:75): Add early return if `uiElements.mapUI == nil` or `uiElements.mapUI:GetVisible() == false`
- In `_fctUpdateHandler` (events.lua): Gate `internal.processFX()` behind a visibility check — animated rift icons don't need to rotate when the map is hidden
- The zoom label handler (map.lua:481-485) is negligible but could also be gated

---

### PRIORITY 2: Avoid Full Element Iteration on Every Coordinate Change

**Problem:** `_fctUpdateElements()` (map.lua:307-339) iterates ALL elements (potentially 100-300+) on every `SetCoord()` call. `SetCoord` fires every time the player moves (unit coordinate change events, multiple times per second).

**Files:**
- `Libs/LibMap/ui/map/map.lua:307-339` — `_fctUpdateElements()`
- `Libs/LibMap/ui/map/map.lua:568-616` — `ui:SetCoord()`

**Fix — Dirty Flag + Throttled Culling:**
- Add a `elementsDirty` flag, initially `false`
- When `SetCoord` or `_fctPan` is called, set `elementsDirty = true` but DON'T call `_fctUpdateElements()` immediately
- Run `_fctUpdateElements()` from the zoom label's existing `Event.System.Update.Begin` handler (map.lua:481-485) only when `elementsDirty == true`, at most once per frame
- This collapses multiple coord updates within a single frame into one culling pass
- Still call `_fctUpdateElements()` immediately on zoom changes and `AddElement` since those need instant feedback

**Alternative consideration:** A spatial index (grid-based) would be ideal for large element counts, but the complexity is high and the dirty-flag approach should provide a major improvement with minimal code changes. Can be revisited if still insufficient.

---

### PRIORITY 3: Stop Allocating `coordsArea` Table on Every Movement

**Problem:** `coordsArea = { x1 = ..., y1 = ..., x2 = ..., y2 = ... }` creates a new table on every `SetCoord()` call (map.lua:610) and every `_fctPan()` call (map.lua:414). This generates garbage for the GC on every player movement.

**Files:**
- `Libs/LibMap/ui/map/map.lua:610-612` — in `SetCoord`
- `Libs/LibMap/ui/map/map.lua:414-416` — in `_fctPan`

**Fix:**
- Initialize `coordsArea` once at construction: `local coordsArea = { x1 = nil, y1 = nil, x2 = nil, y2 = nil }`
- Mutate fields in-place instead of creating a new table:
  ```lua
  coordsArea.x1 = mapX1 + (-x) * xPixel
  coordsArea.y1 = mapY1 + (-y) * yPixel
  coordsArea.x2 = coordsArea.x1 + maskWidth * xPixel
  coordsArea.y2 = coordsArea.y1 + maskHeight * yPixel
  ```

---

### PRIORITY 4: Hoist `RESOURCE_TYPE_MAP` Out of `mapAdd()`

**Problem:** `mapAdd()` (map_core.lua:223-232) creates a new `RESOURCE_TYPE_MAP` table literal on every call. This function is called for every single element added to the map.

**Files:**
- `modules/map/map_core.lua:223-232`

**Fix:**
- Move the `RESOURCE_TYPE_MAP` table to module scope (after the local variable declarations around line 17), so it's created once at load time.

---

### PRIORITY 5: Optimize `processFX()` — Remove Redundant Visibility Check

**Problem:** `processFX()` (fx.lua:60-88) checks `details.frame:GetVisible()` twice — once at line 71 and again at line 75. The second check is redundant.

**Files:**
- `Libs/LibMap/fx/fx.lua:71, 75`

**Fix:**
- Remove the second `details.frame:GetVisible() == true` check at line 75
- Cache `math.rad` locally (it's currently using `mathRad` which is already cached — verify this exists, if not add it)

---

### PRIORITY 6: Optimize `RemoveElement` — Reverse Lookup for `checkIdentical`

**Problem:** `RemoveElement` (map.lua:824-841) does a linear scan of ALL `checkIdentical` entries using `LibEKL.Tools.Table.IsMember()` to find which duplicate group an element belongs to. This is O(n*m) where n = number of duplicate groups and m = average group size.

**Files:**
- `Libs/LibMap/ui/map/map.lua:815-851`

**Fix:**
- Add a reverse-lookup table `elementToCheckKey = {}` that maps element ID → checkKey
- In `AddElement` (line 660/671), when inserting into `checkIdentical[checkKey]`, also set `elementToCheckKey[newElement.id] = checkKey`
- In `RemoveElement`, use `elementToCheckKey[removeElement]` for O(1) lookup instead of scanning all groups
- Clean up `elementToCheckKey[removeElement] = nil` after removal

---

### PRIORITY 7: Throttle `map.UpdateWaypointArrows()`

**Problem:** `map.UpdateWaypointArrows()` (map_elements.lua:148-215) is called on every `unitChange` for the player (map_core.lua:466). It does expensive math, creates canvas shapes, and calls `SetShape()` for every active waypoint — all on every player coordinate change.

**Files:**
- `modules/map/map_elements.lua:148-215`
- `modules/map/map_core.lua:466`

**Fix:**
- Add throttling: track `lastWaypointUpdate` timestamp, skip if less than 0.2 seconds since last update
- Only compute when there are active waypoints (`next(mapData.waypoints) ~= nil`)

---

### PRIORITY 8: Optimize `_fctUpdateCoord` on Mouse Move

**Problem:** On every mouse cursor move event over the map, `_fctUpdateCoord()` runs `string.format` and fires a custom event. During panning, the cursor move handler also calls `_fctPan()` which cascades into tile updates + element visibility.

**Files:**
- `Libs/LibMap/ui/map/map.lua:256-282, 927-934`

**Fix:**
- This is partially addressed by Priority 2 (dirty flag for element updates)
- Additionally, in `_fctUpdateCoord`, throttle the coord label update to avoid `string.format` on every pixel of mouse movement — update at most every 0.05s or when integer coordinates change

---

### PRIORITY 9: Cache `tonumber(mapInfo.x1/x2/y1/y2)` Conversions

**Problem:** `tonumber(mapInfo.x1)`, `tonumber(mapInfo.x2)`, etc. are called repeatedly throughout the code — in `SetCoord`, `_fctPan`, `_fctUpdateElements`, `_fctUpdateTiles`, `_zoomTowardCursor`, `AddElement`. These are redundant when mapInfo hasn't changed.

**Files:**
- `Libs/LibMap/ui/map/map.lua` — lines 315-318, 403-406, 456-459, 576-579, 601-605, 738-742, plus `_fctUpdateTiles` lines 378-381

**Fix:**
- Cache the numeric values once when `mapInfo` is set (in `ui:SetMap()` at line 526):
  ```lua
  local mapX1n, mapX2n, mapY1n, mapY2n  -- cached numeric mapInfo coords
  -- in SetMap, after mapInfo assignment:
  mapX1n = tonumber(mapInfo.x1) or 0
  mapX2n = tonumber(mapInfo.x2) or 0
  mapY1n = tonumber(mapInfo.y1) or 0
  mapY2n = tonumber(mapInfo.y2) or 0
  ```
- Replace all `tonumber(mapInfo.x1)` etc. with the cached locals

---

### PRIORITY 10: Optimize `AddElement` Duplicate Check String

**Problem:** `tostring(newElement.coordX) .. tostring(newElement.coordY) .. tostring(newElement.coordZ) .. tostring(newElement.type)` (map.lua:657) does 4 `tostring()` calls + 3 string concatenations per AddElement.

**Files:**
- `Libs/LibMap/ui/map/map.lua:657`

**Fix:**
- Use `string.format` which is more efficient for multi-value string building:
  ```lua
  local checkKey = stringFormat("%s:%s:%s:%s", newElement.coordX or "", newElement.coordY or "", newElement.coordZ or "", newElement.type or "")
  ```

---

## Implementation Order

1. **Priority 4** — Hoist `RESOURCE_TYPE_MAP` (trivial, nkUI-side, zero risk)
2. **Priority 3** — Mutate `coordsArea` in-place (LibMap, low risk)
3. **Priority 9** — Cache `tonumber(mapInfo.*)` (LibMap, low risk)
4. **Priority 5** — Remove redundant GetVisible in processFX (LibMap, trivial)
5. **Priority 1** — Gate per-frame handlers on visibility (both sides, moderate)
6. **Priority 2** — Dirty flag for element culling (LibMap, moderate complexity, highest impact)
7. **Priority 7** — Throttle waypoint arrows (nkUI, low risk)
8. **Priority 6** — Reverse lookup for checkIdentical (LibMap, moderate)
9. **Priority 10** — Optimize checkKey string (LibMap, trivial)
10. **Priority 8** — Throttle mouse coord label (LibMap, low risk)

---

## Verification

1. **In-game functional test:** Load into a zone with many elements (POIs, quests, resources). Verify all markers still appear correctly.
2. **Panning test:** Drag the map — markers should still appear/disappear correctly at edges.
3. **Zoom test:** Zoom in/out — elements should scale and cull properly.
4. **Zone change test:** Change zones — old elements removed, new ones appear.
5. **Visibility test:** Close the map, walk around, reopen — no stale state, elements positioned correctly.
6. **Animation test:** Verify rift icons still animate when map is open, stop when map is closed.
7. **Waypoint test:** Set waypoints, verify arrows still render (may update slightly less frequently).
8. **nkDebug trace comparison:** If nkDebug is available, compare processFX and UpdateElements trace times before/after.

---

## Files to Modify

| File | Changes |
|------|---------|
| `modules/map/map_core.lua` | Hoist RESOURCE_TYPE_MAP to module scope |
| `modules/map/event.lua` | Gate SystemUpdate on map visibility |
| `modules/map/map_elements.lua` | Throttle UpdateWaypointArrows |
| `Libs/LibMap/ui/map/map.lua` | Mutate coordsArea in-place, dirty flag for _fctUpdateElements, cache mapInfo numbers, optimize checkKey, reverse lookup for checkIdentical, throttle mouse coord |
| `Libs/LibMap/fx/fx.lua` | Remove redundant GetVisible check |
| `Libs/LibMap/events/events.lua` | Gate processFX on map visibility |
