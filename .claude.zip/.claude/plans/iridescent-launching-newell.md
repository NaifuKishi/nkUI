# Phase 1: SavedVar Extension for Keybind Labels

## Context

The action bar module has no keybinding support (RIFT API limitation). The plan is to display
user-defined key labels on action icons as cosmetic overlays. Phase 1 adds `keyBind` as a new
field to the slot data structure and ensures it survives the SavedVar lifecycle correctly.

## What Changes

### 1. `modules/actionbar/actionbar.lua`

**Add `keyBind = nil` to `data.defaultBar`** (line 284):

```lua
data.defaultBar = {
    name             = string.format("bar %d", 1),
    layer            = 1,
    show             = true,
    interactive      = false,
    vertical         = false,
    trigger          = "none",
    triggerTarget    = nil,
    cols             = 12,
    rows             = 1,
    scale            = 100,
    x                = 300,
    y                = 800,
    outOfCombatAlpha = 100,
    inCombatAlpha    = 100,
    slots            = {},
    padding          = 0,
    -- no change needed here: keyBind lives on slots[n], not on the bar
}
```

`keyBind` lives at the **slot** level (`slots[buttonIndex].keyBind`), NOT the bar level.
`data.defaultBar` has `slots = {}` (empty), so no change to `data.defaultBar` itself is needed.

**No migration code needed** — `UpdateSettings` only touches keys present in `_defaults`, which
stops at the `actionBars` flat config level (no `bars` key in `_defaults`). Existing slot tables
will simply be missing `keyBind`, which is treated as `nil` everywhere — safe.

### 2. `modules/actionbar/actionicon.lua`

**In `frame:ClearItem()`** — after clearing `thisItemKey` etc., explicitly clear keyBind in
SavedVars and call `frame:SetKeyBind(nil)` (Phase 2 will add this method). Add to the
reset block at line 267-274:

```lua
-- clear keyBind from SavedVars slot (do not wipe entire slot since Clear writes {} anyway)
local role = inspectTEMPORARYRole()
if data.actionBarSetup and data.actionBarSetup.roles[role] then
    local slot = data.actionBarSetup.roles[role].bars[barIndex].slots[buttonIndex]
    if slot then slot.keyBind = nil end
end
```

**In `fctCheckDrop()`** — the drag-drop write at line 235 writes a fresh table
`{ itemType = cType, itemKey = cHeld, macroIcon = nil }` which has no `keyBind` field.
This is fine — `keyBind = nil` (absent key) is the correct default for a newly dropped slot.
**No change needed here.**

**In `macroEditDialog.lua` save handler** — line 130 also writes a fresh table without
`keyBind`. Again, this is the correct behavior: saving a new macro should not carry over a
stale keybind label. **No change needed here.** (If the user wants to preserve keyBind across
macro saves, that can be addressed in a later phase.)

### 3. `modules/actionbar/actionbar.lua` — `actionBar:Populate()`

**In `actionBar:Populate()`** (lines 107-135) — after `SetItem` is called per slot, read
`keyBind` from SavedVars and call `frame:SetKeyBind()`. This is the primary
"restore-from-SavedVars on login / role change" path.

Add to the slot-population block at line 121 area:

```lua
-- existing:
if slotInfo ~= nil then
    if slotInfo.macroCD ~= nil then
        thisRow[colIndex]:SetItem(...)
    else
        thisRow[colIndex]:SetItem(...)
    end
    thisRow[colIndex]:SetUsable(true)
    -- NEW: restore keybind label
    thisRow[colIndex]:SetKeyBind(slotInfo.keyBind)
else
    thisRow[colIndex]:ClearItem()
end
```

**In `actionBar:Clear()`** (lines 139-148) — after `ClearItem()` per slot, call
`SetKeyBind(nil)` to hide the label:

```lua
thisRow[colIndex]:ClearItem()
thisRow[colIndex]:SetCooldown()
thisRow[colIndex]:SetKeyBind(nil)  -- NEW
```

## Critical Files

| File | Lines | Change |
|------|-------|--------|
| `modules/actionbar/actionbar.lua` | 107-135 | Add `SetKeyBind(slotInfo.keyBind)` in `Populate()` |
| `modules/actionbar/actionbar.lua` | 139-148 | Add `SetKeyBind(nil)` in `Clear()` |
| `modules/actionbar/actionicon.lua` | 246-281 | Add keyBind nil-clear in `ClearItem()` |

**Not touched in Phase 1:**
- `settings/settings.lua` — no changes to `_defaults` (keyBind is slot-level, not bar config)
- `RiftAddon.toc` — no new files added in Phase 1
- `macroEditDialog.lua` — fresh slot tables correctly have no keyBind (nil = correct default)

## Notes on Safety

- `keyBind = nil` (missing key) is indistinguishable from `keyBind = nil` (explicit nil) — both result in no label shown
- `UpdateSettings` will never touch slot data, so existing characters' bars are safe
- The runtime role-expansion path (`LibEKL.Tools.Table.Copy(data.defaultBar)`) creates new bars with `slots = {}` — new slots get no keyBind by default, which is correct
- Phase 1 only wires up the data layer; the `frame:SetKeyBind()` method stub is called but not yet implemented (Phase 2). Calls to `SetKeyBind` must be guarded with `if frame.SetKeyBind then` or Phase 2 must land before Phase 1 is run in-game. Plan: implement `SetKeyBind` stub in Phase 1 as a no-op to avoid errors.

## SetKeyBind Stub (in `actionicon.lua`)

Add a minimal no-op stub so Phase 1 calls don't error before Phase 2 lands:

```lua
function frame:SetKeyBind(key)
    -- stub: full implementation in Phase 2
end
```

## Verification

1. Assign an ability to a slot (drag-drop)
2. Add a debug print in `Populate()` to confirm `slotInfo.keyBind` is read (nil on first use, string after Phase 2+3)
3. Right-click slot to clear — confirm slot entry in `nkUISetup...slots[n]` no longer has `keyBind` (or has `keyBind = nil`)
4. Relog — confirm bars populate without Lua errors
5. Change role — confirm `Populate()` called without errors
