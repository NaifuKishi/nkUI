# Migration Plan: nkWardrobe → nkUI Wardrobe Module

## Context

nkWardrobe is a standalone Rift addon for managing equipment sets. This plan migrates its core functionality into nkUI as an integrated module, replacing EnKai with LibEKL, adding a lowerbar set-switcher element, and adding wardrobe-aware item categorization in OneBag.

**Omitted features:** Role auto-switch, set linking (master/linked), set switcher bar/button, all settings pane items, nkRebuff/kAlert/yell integrations, nkPanel plugin, tutorial wizard.

**User decisions:**
- **SavedVars:** Character-scoped (`nkUIWardrobe`, `nkUIWardrobeBackup`) via new entries in `RiftAddon.toc`
- **Config access:** `/nkui wardrobe` slash command + right-click on lowerbar element
- **OneBag:** Items in a wardrobe set appear ONLY in the set-named category (removed from normal category)

---

## New Files

| File | Purpose |
|------|---------|
| `modules/wardrobe/wardrobe.lua` | Core logic: data access, equip mover, tooltip integration, slash command |
| `modules/wardrobe/wardrobeUI.lua` | Configuration dialog (set management, equipment assignment) |
| `modules/lowerbar/wardrobe.lua` | Lowerbar element with dropdown set switcher |
| `gfx/lowerbarWardrobe.png` | 16x16 icon for lowerbar element (copy/adapt from nkWardrobe) |
| `gfx/equipslot_*.png` (20 files) | Equipment slot icons (copy from nkWardrobe/gfx/) |
| `gfx/editPen.png` | Edit icon (copy from nkWardrobe/gfx/) |

## Modified Files

| File | Changes |
|------|---------|
| `RiftAddon.toc` | Add 3 new lua files to RunOnStartup, add 2 character-scoped SavedVariables |
| `main.lua` | Add `/nkui wardrobe` command handler, add `wardrobeInit()` call in startup |
| `locales/localizationEN.lua` | Add `wardrobe` section with all UI strings + soul icon lists |
| `locales/localizationDE.lua` | Add `wardrobe` section (German translation) |
| `locales/localizationFR.lua` | Add `wardrobe` section (French stubs, EN fallback) |
| `modules/lowerbar/lowerbar.lua` | Add `lowerBar.lowerBarWardrobe()` call, change divisor from /8 to /9 |
| `modules/lowerbar/roles.lua` | Adjust position multiplier (width*2 → width*3) |
| `modules/lowerbar/currency.lua` | Adjust position multiplier (-width*1 → -width*2) |
| `modules/lowerbar/experience.lua` | Adjust position multiplier (width*3 → width*4) |
| `modules/lowerbar/faction.lua` | Adjust position multiplier (-width*3 → -width*4) |
| `modules/lowerbar/vitality.lua` | Adjust position multiplier (-width*2 → -width*3) |
| `modules/lowerbar/social.lua` | Update width calculation only (divisor /8 → /9) |
| `modules/lowerbar/fps.lua` | Update width calculation only (divisor /8 → /9) |
| `modules/lowerbar/location.lua` | Update width calculation only (divisor /8 → /9) |
| `modules/lowerbar/timeDate.lua` | Update width calculation only (divisor /8 → /9) |
| `modules/onebag/onebag.lua` | Inject wardrobe set categories in `bagContent()` |
| `modules/onebag/itemCategories.lua` | Add `oneBag.getWardrobeSetForItem()` function |
| `settings/settings.lua` | Add `wardrobe` defaults to `_defaults` |

---

## Phase 1: Core Wardrobe Module

### 1.1 Copy Graphics Assets
Copy from `nkWardrobe/gfx/` to `nkUI/gfx/`: all `equipslot_*.png` (20 files) + `editPen.png`. Create `lowerbarWardrobe.png` (16x16 wardrobe icon, can reuse `equipslot_chest.png` scaled down or use Rift's `CharacterSheet_I1DB.dds` at runtime).

### 1.2 SavedVariables (`RiftAddon.toc`)
Add to SavedVariables section:
```
nkUIWardrobe   = "character",
nkUIWardrobeBackup = "character"
```

### 1.3 Locale Strings
Add `wardrobe` key to `langTexts` in all 3 locale files. Include:
- UI labels: set name, equip set, new set, delete set, copy set, current equipment, equipment header, inventory header
- Error messages: errGettingItem, errMovingItem, errLastSet
- Confirm messages: msgRemoveSetConfirm, msgLoadCurrentEquip, msgBankWarning
- Tooltip: partOfSets
- Lowerbar: activeSetLabel
- Startup/load messages
- Soul icon lists per calling (from nkWardrobe locale files)
- Bag/bank labels, icon label

### 1.4 Defaults (`settings/settings.lua`)
Add to `_defaults.modules`:
```lua
wardrobe = { activate = true }
```

### 1.5 Core Module (`modules/wardrobe/wardrobe.lua`)
**Namespace:** `privateVars.wardrobe = {}`

**Data:**
- `data.wardrobeSlots` = 20 slot name array (from nkWardrobe's `data.slots`)
- Character data helper: `wardrobe.getCharData()` returns `nkUIWardrobe` (with defaults applied)

**Default structure for `nkUIWardrobe`:**
```lua
{
    activeSet = 1,
    sets = { { name = "Set 1", items = {}, bag = 1, bank = 0, icon = "" } }
}
```

**Functions to port from nkWardrobe (replace EnKai → LibEKL):**
- `wardrobe.wearEquip(setNo)` — equip a set (simplified: no linked sets, no role/rebuff/yell)
- `wardrobe.equipMover(moveList)` — coroutine dispatcher (use closure upvalues instead of para1/para2)
- `_fctEquipMoverCoRoutine(thisList, errorFlag)` — the actual coroutine (port as-is, replace `EnKai.inventory` → `LibEKL.Inventory`)
- `wardrobe.errorMover()` — retry failed moves
- `wardrobe.tooltipInfo()` — Event.Tooltip handler showing set membership
- `wardrobe.showUI()` — open config dialog (calls wardrobeUI)

**Secure context note:** `wearEquip` must be dispatched via `LibEKL.Events.AddInsecure()` when called from secure lowerbar context.

**Startup:** `internalFunc.wardrobeInit()`:
1. Apply defaults to `nkUIWardrobe`
2. Run one-time migration from nkWSetup if present
3. Pre-cache item types into `nkUIWardrobeBackup`
4. Attach `Event.Tooltip` handler
5. Console startup message

**Migration from nkWardrobe:**
```lua
if nkWSetup and nkWSetup.sets and #nkWSetup.sets > 0 then
    -- Only migrate if nkUI wardrobe is fresh (default single empty set)
    if #nkUIWardrobe.sets == 1 and next(nkUIWardrobe.sets[1].items) == nil then
        -- Copy sets (name, items, bag, bank, icon only)
        -- Copy activeSet
        -- Copy nkWBackup → nkUIWardrobeBackup
        -- Console message confirming migration
    end
end
```

### 1.6 Slash Command (`main.lua`)
Add to `commandHandler`:
```lua
elseif stringFind(commandline, "wardrobe") ~= nil then
    if nkUISetup and nkUISetup.modules and nkUISetup.modules.wardrobe and nkUISetup.modules.wardrobe.activate then
        internalFunc.wardrobeShowUI()
    end
```

Add `internalFunc.wardrobeInit()` call in `Event.Unit.Availability.Full` handler after inventory init, guarded by `nkUISetup.modules.wardrobe.activate`.

---

## Phase 2: Configuration UI

### 2.1 Config Dialog (`modules/wardrobe/wardrobeUI.lua`)
Port from `nkWardrobe/ui.lua`, converting `EnKai.uiCreateFrame` → `LibEKL.UICreateFrame`, `EnKai.*` → `LibEKL.*`.

**Window:** `nkWindow` (700×500), strata 'dialog', closeable, nkUI-styled (same gradient/border as settings window).

**Single tab "Sets"** (no tab pane needed since Settings tab is omitted):

**Left panel (controls):**
- Set selection combobox (`nkCombobox`)
- Set name edit (pencil icon + `nkTextfield`)
- Icon selection combobox (soul icons + inventory icons)
- Buttons: "Equip set", "New set", "Copy set", "Delete set"
- "Current equipment" button (stores currently worn gear into selected set)
- Bag/bank selection comboboxes
- "Get from bank" / "Store into bank" buttons

**Right panel (equipment display):**
- "Equipment of the set" header + 20 slot frames (30×30 each with slot icon, item texture overlay)
- "Inventory" header + scrollable grid of inventory items (30 visible slots)
- Click inventory item → assigns to appropriate equipment slot
- Click equipment slot → clears item from set

**Key functions to port:**
- `_fctStoreEquip()` — scans all 20 equipment slots, stores item IDs into set
- `_fctUpdateSetSelectValues()` — rebuilds combo values
- `_internal.updateUIOnSetChange()` — refreshes equipment display when switching sets
- `_fctBuildEquipSlotUI()` — creates the 20-slot grid
- `_fctBuildInventoryUI()` — creates scrollable inventory grid
- `_fctGetBankItems()` / `_fctPutBankItems()` — bank move operations

**Removed from port:** Linked set combobox, role combobox, nkRebuff combobox, kAlert combos, yell channel/message fields, Settings tab entirely.

---

## Phase 3: Lowerbar Wardrobe Element

### 3.1 Width Redistribution
All 9 existing lowerbar module files must change their width calculation from `/8` to `/9`. Six modules also need adjusted position multipliers.

**New layout (left to right):**

| Pos | Module | Anchor | Offset |
|-----|--------|--------|--------|
| 0 | social | CENTERLEFT | width*0 |
| 1 | fps | CENTERLEFT | width*1 |
| 2 | **wardrobe** | CENTERLEFT | width*2 |
| 3 | roles | CENTERLEFT | width*3 |
| 4 | experience | CENTERLEFT | width*4 |
| — | timeDate | CENTER | 0 |
| 4 | faction | CENTERRIGHT | -(width*4) |
| 3 | vitality | CENTERRIGHT | -(width*3) |
| 2 | currency | CENTERRIGHT | -(width*2) |
| 1 | location | CENTERRIGHT | -(width*1) |

### 3.2 Lowerbar Element (`modules/lowerbar/wardrobe.lua`)
Follow `roles.lua` pattern exactly:

- `datasetFrame` (nkFrame, restricted secure mode)
- `datasetText` (nkText) showing active set name: `"Set: <font color='#3C99D7'>SetName</font>"`
- `datasetIcon` (nkTexture, 16×16) showing set icon or default wardrobe icon
- `setSwitch` (nkFrame) positioned at BOTTOMCENTER→TOPCENTER above text, hidden by default

**Left-click:** Toggle dropdown showing all sets. Each set entry is an nkText. Clicking a set calls `wardrobe.wearEquip(setNo)` via `LibEKL.Events.AddInsecure()`.

**Right-click:** Open wardrobe config dialog via `internalFunc.wardrobeShowUI()`.

**Updates:** Listen for a custom event or call update function after `wearEquip` completes to refresh the displayed set name/icon.

**Redraw:** Adjusts font sizes per `nkUISetup.modules.lowerBar.fontSize`.

### 3.3 Registration (`modules/lowerbar/lowerbar.lua`)
Add `lowerBar.lowerBarWardrobe()` call in `build()` function, between `lowerBar.fps()` and `lowerBar.lowerBarRoles()`.

---

## Phase 4: OneBag Integration

### 4.1 Wardrobe Category Detection (`modules/onebag/itemCategories.lua`)
Add function:
```lua
function oneBag.getWardrobeSetForItem(itemId, itemType)
    if not nkUIWardrobe or not nkUIWardrobe.sets then return nil end
    for idx, setData in ipairs(nkUIWardrobe.sets) do
        if setData.items then
            for slot, setItemId in pairs(setData.items) do
                if setItemId == itemId then return setData.name end
                -- Fallback: check by item type via backup
                if nkUIWardrobeBackup and nkUIWardrobeBackup[setItemId] == itemType then
                    return setData.name
                end
            end
        end
    end
    return nil
end
```

### 4.2 Category Override (`modules/onebag/onebag.lua`)
In `oneBag.bagContent()`, after determining `realCategory` for each item, check wardrobe:
```lua
local wardrobeCategory = oneBag.getWardrobeSetForItem(v.id, v.type)
if wardrobeCategory then
    realCategory = wardrobeCategory  -- Override: item goes to set category only
end
```

This replaces the normal category so items in a wardrobe set appear ONLY under the set-named category.

---

## Phase 5: Polish & Migration

- Add manual section for Wardrobe in `settings/manual.lua`
- Add commandline hint in startup messages: `/nkui wardrobe`
- One-time migration from `nkWSetup` → `nkUIWardrobe` (see Phase 1.5)

---

## RiftAddon.toc Changes

Add to `RunOnStartup` (after onebag files, before settings):
```
"modules/wardrobe/wardrobe.lua",
"modules/wardrobe/wardrobeUI.lua",
"modules/lowerbar/wardrobe.lua",
```

Add to `SavedVariables`:
```
nkUIWardrobe    = "character",
nkUIWardrobeBackup = "character"
```

---

## Verification

1. **Startup:** Load nkUI, verify no errors, verify `nkUIWardrobe` SavedVar created with defaults
2. **Slash command:** `/nkui wardrobe` opens config dialog
3. **Config dialog:** Create set, rename, assign icon, store current equipment, verify slots display correctly
4. **Equip:** Click "Equip set" in dialog, verify items move from bags to equipment slots via coroutine
5. **Lowerbar:** Verify 9 modules display evenly, wardrobe element shows active set name, left-click shows dropdown, clicking a set equips it, right-click opens config
6. **OneBag:** Open bag, verify items belonging to a wardrobe set appear under the set-named category (not their normal category)
7. **Migration:** With existing nkWardrobe SavedVars present, verify sets are migrated on first load
8. **Bank ops:** Store to bank / get from bank works correctly
9. **Tooltip:** Hover over an item in bags, verify set membership shown if item is in a set
