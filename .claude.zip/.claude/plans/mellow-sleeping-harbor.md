# Plan: Minion Manager Modul (Simple)

## Context

nkUI benötigt ein neues Modul, das die RIFT Minion API nutzt, um Spielern zu ermöglichen, Minions auf Abenteuer zu schicken und abgeschlossene Missionen abzuholen. Die erste Version ist bewusst einfach gehalten: zwei Panels (Minions links, Abenteuer rechts) + eine Active-Missions-Sektion unten. Kein Auto-Send, keine Tabs, keine Filter.

---

## Neue Dateien

### `modules/minionManager/minionManager.lua`
- Namespace `privateVars.minionManager = {}` anlegen
- `minionManager.context = UI.CreateContext("nkUI.minionManager")` auf Modulebene
- `isInit = false` Guard-Variable
- `_timerUuid` für den Periodic-Timer
- `internalFunc.minionManagerInit()`: Toggle bei wiederholtem Aufruf, sonst `internalFunc.uiMinionManager()` aufrufen
- `internalFunc.uiMinionManager()`: UI bauen via `minionManager.buildUI()`, `minionManager.populate()` aufrufen, Periodic-Timer starten (10s)
- Alle Rift-API-Funktionen am Dateianfang lokal cachen

### `modules/minionManager/ui.lua`
- Konstanten: `WIN_W=700`, `WIN_H=550`, `LEFT_W=220`, `RIGHT_W=440`, `ROW_H=36`, `ICON_SIZE=28`, `PAD=6`, `ACTIVE_H=160`
- Selection-Upvalue: `local _selectedMinionId = nil`
- Recycling-Bins: `_minionBin`, `_adventureBin`, `_activeBin`
- Content-Frame-Referenzen: `_minionContent`, `_adventureContent`, `_activeContent`

**Row-Factories (erstellen oder recyceln):**
- `_createMinionRow(parent)` → nkFrame mit icon (nkTexture 28×28), nameText, levelText, highlight-Canvas (3px linker Balken)
  - Click → `_applySelection(minionId)`
  - Methoden: `Update(id, details)`, `SetHighlight(bool)`, `GetMinionId()`
- `_createAdventureRow(parent)` → nkFrame mit nameText, durationText, sendBtn (nkButton)
  - Send-Click → prüft `_selectedMinionId`, ruft `pcall(commandMinionSend, ...)`, nach 3 Frames `populate()`
- `_createActiveRow(parent)` → nkFrame mit nameText, timeText (FiraMonoMedium), claimBtn (nkButton, initial versteckt)
  - Claim-Click → `pcall(commandMinionClaim, ...)`, nach 3 Frames `populate()`
  - Methoden: `Update(advId, details)`, `RefreshTime(newRemaining)`, `GetAdventureId()`

**Hilfsfunktionen:**
- `_applySelection(id)` → setzt `_selectedMinionId`, loopt über `_minionRows` für Highlight
- `_restackRows(rows, contentFrame)` → TOPLEFT-Anker setzen, ContentFrame-Höhe aktualisieren
- `_clearRows(rows, bin)` → alle Rows `SetVisible(false)`, in Bin schieben

**`minionManager.populate()`:**
1. Alle drei Row-Listen clearen
2. `pcall(inspectMinionList)` → `pcall(inspectMinionDetail, ids)` → idle Minions in linkes Panel
3. Selection nach Repopulate validieren
4. `pcall(inspectAdventureList)` → `pcall(inspectAdventureDetail, ids)` → verfügbare Abenteuer rechts
5. Nochmals alle Minions: busy Minions → adventureIds sammeln → Active Rows befüllen

**`minionManager.refreshActiveMissions()`:** Re-query `inspectMinionDetail` → `row:RefreshTime(t)` für alle `_activeRows`

**`minionManager.buildUI()`:**
- nkWindow 700×550, `SetPoint("TOPLEFT", UIParent, ..., nkUISetup.modules.minionManager.x/y)`
- `LibEKL.Events[windowName].Moved` → Position in nkUISetup speichern
- Sections-Labels (nkText) für linke/rechte/untere Sektion
- `nkScrollPane` links (220px) + `UI.CreateFrame("Frame", ...)` als Content
- `nkScrollPane` rechts (440px) + Content Frame
- Horizontaler Divider (nkCanvas, Gradient-Fade)
- `nkScrollPane` unten full-width für Active Missions + Content Frame

### `settings/settings-tabMinionManager.lua`
- `settingsUI.uiConfigTabMinionManager(name, parent)` Funktion
- `frame:build()` mit activate-Checkbox → bei Änderung `LibEKL.UI.reloadDialog("nkUI")`

---

## Geänderte Dateien

### `RiftAddon.toc`
Nach den actionbar-Einträgen in `RunOnStartup` einfügen:
```
"modules/minionManager/minionManager.lua",
"modules/minionManager/ui.lua",
"settings/settings-tabMinionManager.lua",
```

### `main.lua`
1. In der `commandHandler`-Funktion neuen `elseif` Branch:
```lua
elseif stringFind(commandline, "minion") ~= nil then
    if nkUISetup and nkUISetup.modules and nkUISetup.modules.minionManager
       and nkUISetup.modules.minionManager.activate then
        internalFunc.minionManagerInit()
    end
```
2. Keine Auto-Init im `Unit.Availability.Full`-Handler nötig — Modul öffnet sich nur auf Befehl.

### `settings/settings.lua`
1. In `_defaults.modules` nach `wardrobe`:
```lua
minionManager = { activate = true, x = 200, y = 200 },
```
2. In `internalFunc.setupUI()` nach dem letzten `tabPane:AddPane`:
```lua
local paneTabMinionManager = settingsUI.uiConfigTabMinionManager(name..".tab.MinionManager", tabPane)
tabPane:AddPane({ label=langTexts.settings.minionManager, effect={strength=3},
    frame=paneTabMinionManager, initFunc=function() paneTabMinionManager:build() end }, false)
```

### `locales/localizationEN.lua`
```lua
minionManager = {
    windowTitle = "Minion Manager",
    available   = "Available Minions",
    adventures  = "Adventures",
    active      = "Active Missions",
    send        = "Send",
    claim       = "Claim",
    done        = "Done!",
    noMinion    = "Select a minion first",
},
-- Im settings-Block:
-- minionManager = "Minion Manager",
```

### `locales/localizationDE.lua`
```lua
minionManager = {
    windowTitle = "Gefolgsleute",
    available   = "Verfügbare Gefolgsleute",
    adventures  = "Abenteuer",
    active      = "Aktive Missionen",
    send        = "Schicken",
    claim       = "Abholen",
    done        = "Fertig!",
    noMinion    = "Zuerst einen Gefolgsmann auswählen",
},
-- Im settings-Block:
-- minionManager = "Minion Manager",
```

---

## UI-Layout (ASCII)

```
┌─────────────────────────────────────────────────────────────────────┐
│  Minion Manager                                                  [X] │
├───────────────────────┬─────────────────────────────────────────────┤
│ Available Minions     │ Adventures                                   │
│ ─────────────────── ↕ │ ─────────────────────────────────────────  ↕│
│ [icon] Pip   Lv 12    │ Cave Delve     2h 30m         [Send]         │
│ [icon] Nova  Lv 15    │ Dark Forest    4h 00m         [Send]         │
│ [icon] Rex   Lv 8     │ Ancient Ruins  1h 45m         [Send]         │
│                       │                                              │
├───────────────────────┴──────────────────────────────────────────────┤
│ Active Missions                                                     ↕ │
│ ─────────────────────────────────────────────────────────────────── │
│ Swamp Delve         1h 22m                                           │
│ Forest Hunt         Done!                                   [Claim]  │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Datenfluss

**Öffnen:** `/nkui minion` → `minionManagerInit()` → `buildUI()` + `populate()` + Timer (10s)

**Send:** Klick auf [Send] → `_selectedMinionId` prüfen → `pcall(Command.Minion.Send, minionId, advId)` → 3 Frames warten → `populate()`

**Claim:** Klick auf [Claim] → `pcall(Command.Minion.Claim, advId)` → 3 Frames warten → `populate()`

**Timer:** Alle 10s → `refreshActiveMissions()` → `inspectMinionDetail` neu abfragen → `row:RefreshTime(t)` → bei t≤0 "Done!" + [Claim] einblenden

---

## Wichtige API-Referenzen

```
Inspect.Minion.Minion.List()          → {id → true}
Inspect.Minion.Minion.Detail(id|ids)  → {id → {name, icon, level, status, adventureId, timeRemaining, ...}}
Inspect.Minion.Adventure.List()       → {id → true}
Inspect.Minion.Adventure.Detail(ids)  → {id → {name, duration, slots, minions, ...}}
Command.Minion.Send(minion, adventure)
Command.Minion.Claim(adventure)
```

Status-Werte: `"idle"` (bereit zu senden) | `"busy"` (auf Mission)
Alle Inspect-Calls in `pcall()` wrappen.

---

## Verifikation

1. In-game `/nkui minion` → Fenster öffnet sich
2. Minion anklicken → gelber Highlight-Balken links
3. [Send] klicken → Minion verschwindet aus linker Liste, Abenteuer aus rechter, erscheint in Active
4. Nach Ablauf der Zeit: timeText zeigt "Done!", [Claim]-Button erscheint
5. [Claim] klicken → Active Row verschwindet, Minion zurück in linker Liste
6. Fenster schließen und `/nkui minion` erneut → Position gespeichert
7. Settings → "Minion Manager" Tab → activate Checkbox funktioniert
8. DE-Sprache: alle Texte auf Deutsch
