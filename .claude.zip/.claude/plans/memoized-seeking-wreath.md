# Phase 1A: Browse Tab Implementation Plan

## Context

The auction module (`modules/auction/`) has a complete core data layer (price ring buffer, scan engine, SavedVars) but all four tab bodies are empty placeholders. Phase 1A implements the Browse tab: a searchable, filterable, sortable grid that shows **live AH listings** from a scan, plus a "My Price" column comparing your own listings.

Key files touched:
- `modules/auction/auction-browse.lua` — main implementation file (currently 27-line placeholder)
- `modules/auction/auction.lua` — expose 3 local helpers + update initFunc hook
- `settings/settings.lua` — add `browse` sub-table to auction defaults
- `locales/localizationEN.lua`, `localizationDE.lua`, `localizationFR.lua` — add 2 missing strings

---

## 1. Expose Helpers in auction.lua

Three local symbols need to be reachable from `auction-browse.lua`:

| Symbol | Current | Change |
|---|---|---|
| `makeBtn` | local function | rename to `auction.makeBtn` |
| `formatExpiry` | local function | rename to `auction.formatExpiry` |
| `atAuctionHouse` | local boolean | add `auction.isAtAH()` accessor |
| `browseSearchPending` | local boolean | expose as `auction.browseSearchPending` |

Update the Browse tab `initFunc` in `buildWindow()`:
```lua
initFunc = function()
    if auction.buildBrowseTab then
        auction.buildBrowseTab(browseFrame)
    end
end
```

## 2. settings.lua — Add browse defaults

In the auction defaults block, add a `browse` sub-table:
```lua
auction = {
    activate       = true,
    x              = 300,
    y              = 200,
    autoOpenWithAH = false,
    showInTooltip  = true,
    scanDepth      = 3,
    browse         = { sortCol = 7, sortAsc = true, rarityFilter = {} },
}
```

## 3. Localization — Add 2 strings to all 3 locale files

Add inside the `auction` table:
```lua
colMyPrice  = "My Price",
browseHint  = "Search by name...",
```
(localizationDE.lua: `"Mein Preis"`, `"Nach Name suchen..."`)
(localizationFR.lua: `"Mon Prix"`, `"Rechercher par nom..."`)

## 4. auction-browse.lua — Full Implementation

### 4.1 Namespace & locals

```lua
local addonInfo, privateVars = ...
local auction       = privateVars.auction
local data          = privateVars.data
local internalFunc  = privateVars.internalFunc
local langTexts     = privateVars.langTexts

local InspectAuctionDetail = Inspect.Auction.Detail
local InspectItemDetail    = Inspect.Item.Detail
local InspectShard         = Inspect.Shard
local stringFormat         = string.format
local mathFloor            = math.floor
local tableInsert          = table.insert
local tableSort            = table.sort
local pairs                = pairs
local tostring             = tostring
local pcall                = pcall
```

### 4.2 Module-level state

```lua
local grid          = nil   -- nkGrid widget
local searchInput   = nil   -- nkTextField
local rarityBtns    = {}    -- [0..6] toggle button frames
local browseRows    = {}    -- raw row data before filter, for re-filter on toggle
local GRID_NAME     = "nkUI.auction.browse.grid"
```

### 4.3 Rarity colors (for filter button tints)

```lua
local RARITY_COLOR = {
    [0] = {r=0.8, g=0.8, b=0.8},   -- Common: grey
    [1] = {r=0.1, g=0.9, b=0.1},   -- Uncommon: green
    [2] = {r=0.0, g=0.5, b=1.0},   -- Rare: blue
    [3] = {r=0.6, g=0.1, b=0.9},   -- Epic: purple
    [4] = {r=1.0, g=0.5, b=0.0},   -- Relic: orange
    [5] = {r=1.0, g=0.9, b=0.2},   -- Transcendent: gold
    [6] = {r=0.9, g=0.4, b=0.4},   -- Primalist: pink-red
}
local RARITY_LABEL = { [0]="C", [1]="U", [2]="R", [3]="E", [4]="Rel", [5]="T", [6]="P" }
```

### 4.4 formatCoins local alias

```lua
local function fmtCoins(v)
    if not v or v == 0 then return "-" end
    return internalFunc.formatCoins(v)
end
```

### 4.5 populateBrowseGrid(rawAuctions)

Iterates raw auction ID table, calls `InspectAuctionDetail` + `InspectItemDetail`, builds row tables, applies rarity filter, then calls `grid:SetCellValues(rows)`.

Row format (10 columns):
1. icon path (texture col)
2. item name (string)
3. seller (string)
4. stack size (string)
5. bid (formatted coins)
6. buyout (formatted coins, colored green if < lastLo from getPriceSummary)
7. unit price (formatted coins)
8. vs. vendor ratio (e.g. "3.5x", colored red if > 5x)
9. my price (formatted coins, or "-")
10. `{ value = expiryStr, key = auctionID }` — expiry + row key

**Sorting:** After building rows, sort by `nkUISetup.modules.auction.browse.sortCol` and `.sortAsc`. Columns 5-9 contain formatted strings (not numbers) so sort on raw numeric values stored in a parallel sort-key column or sort the raw data before formatting. Simplest: build a parallel `sortKeys` table and sort rows using raw copper values.

**Own auction data:** Uses `auction.ownAuctions[itemType]` (lowest unit price of player's own listings). Populated by `auction.refreshOwnAuctions()` defined below.

### 4.6 refreshOwnAuctions()

```lua
function auction.refreshOwnAuctions()
    auction.ownAuctions = {}
    local ok, list = pcall(Inspect.Auction.List)  -- returns {[auctionID]=true,...} or nil
    if not ok or not list then return end
    for auctionID in pairs(list) do
        local ok2, detail = pcall(InspectAuctionDetail, auctionID)
        if ok2 and detail and detail.itemType and detail.buyout then
            local unitPrice = mathFloor(detail.buyout / (detail.itemStack or 1))
            local existing  = auction.ownAuctions[detail.itemType]
            if existing == nil or unitPrice < existing then
                auction.ownAuctions[detail.itemType] = unitPrice
            end
        end
    end
end
```

### 4.7 Rarity filter toggle logic

```lua
local function isRarityVisible(rarity)
    local rf = nkUISetup.modules.auction.browse.rarityFilter
    -- empty table = show all
    if not rf or next(rf) == nil then return true end
    return rf[rarity] == true
end

local function toggleRarity(rarity)
    local rf = nkUISetup.modules.auction.browse.rarityFilter
    if rf[rarity] then
        rf[rarity] = nil
    else
        rf[rarity] = true
    end
    -- Re-apply filter to browseRows (re-populate grid from cached data)
    applyFilterAndSort()
    updateRarityBtnVisuals()
end
```

When `rarityFilter` is empty (default), all rarities are shown. When one or more entries are present, only those rarities are shown.

### 4.8 applyFilterAndSort()

Takes `browseRows` (all rows from last scan), filters by rarity and name search text, sorts, calls `grid:SetCellValues()`.

### 4.9 auction.buildBrowseTab(browseFrame)

Layout (browseFrame ≈ 880 × 540px):

```
┌─────────────────────────────────────────────────┐
│ [Search field, 280px]        [Search btn, 80px] │ ← row 0..28px
│ [C][U][R][E][Rel][T][P]  ← rarity toggles, 28px│ ← row 30..58px
│                                                 │
│  nkGrid (880 × ~470px, 30 visible rows)         │ ← row 60..bottom
│  Icon | Item | Seller | Stack | Bid | Buyout    │
│       | Unit | vs.Vnd | MyPrc | Expires         │
└─────────────────────────────────────────────────┘
```

Steps inside `buildBrowseTab`:
1. Create `searchInput` (nkTextField) + Search button
2. Create 7 rarity toggle buttons (30×22 each, coloured per rarity)
3. `LibEKL.Events.CheckEvents(GRID_NAME, true)`
4. Create grid, set font/colors
5. `grid:Layout(COLS, 30)` — async, wait for GridFinished
6. On GridFinished: restore sort from SavedVars (`grid:Sort(cfg.sortCol)`)
7. Attach scan result handler `Event.Auction.Scan` for browse scans
8. Attach search button click → `doSearch(searchInput:GetText())`
9. Attach search field TextfieldChanged → re-filter cached data
10. Attach grid LeftClick → detect header click for sort persistence

### 4.10 Event.Auction.Scan handler

```lua
Command.Event.Attach(Event.Auction.Scan, function(_, info, auctions)
    if info.type ~= "search" then return end
    if not auction.browseSearchPending then return end
    auction.browseSearchPending = false
    auction.refreshOwnAuctions()
    populateBrowseGrid(auctions)
end, "nkUI.Auction.Browse.Scan")
```

### 4.11 Column definitions

| # | Header | Width | Notes |
|---|---|---|---|
| 1 | "" | 28 | texture=true, icon |
| 2 | colItem | 200 | item name, coloured by rarity |
| 3 | colSeller | 100 | |
| 4 | colStack | 40 | center |
| 5 | colBid | 80 | right |
| 6 | colBuyout | 80 | right, green if below lastLo |
| 7 | colUnit | 80 | right |
| 8 | colVendorRatio | 65 | right, red if >5x |
| 9 | colMyPrice | 80 | right |
| 10 | colExpires | 60 | center |

Total: 813px (fits ≈880px body)

---

## 5. File Change Summary

| File | Change |
|---|---|
| `modules/auction/auction.lua` | Expose makeBtn→auction.makeBtn, formatExpiry→auction.formatExpiry, add auction.isAtAH(), auction.browseSearchPending; update initFunc |
| `modules/auction/auction-browse.lua` | Full implementation (~250 LOC) |
| `settings/settings.lua` | Add browse sub-table to auction defaults |
| `locales/localizationEN.lua` | Add colMyPrice, browseHint |
| `locales/localizationDE.lua` | Add colMyPrice, browseHint |
| `locales/localizationFR.lua` | Add colMyPrice, browseHint |

---

## 6. Verification

1. Load addon in RIFT at an Auction House NPC
2. Open nkUI AH window → Browse tab should show search bar + rarity toggles + empty grid
3. Type a name in search, click Search → scan triggers, grid populates with live listings
4. Click column headers → sort toggles; relog and reopen to verify sort persistence
5. Toggle rarity buttons → rows filter correctly
6. Own listings should show their unit price in My Price column
7. Verify no Lua errors in console
